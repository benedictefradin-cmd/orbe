<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.

## What Lovable manages

Rules outside this block are the project's own. Change the pieces below in
Lovable, not by hand. With the [Lovable MCP](https://mcp.lovable.dev)
connected, `send_message` asks Lovable to do it; otherwise ask the user to
use the editor.

- **Database.** Do not add or edit `supabase/migrations/` or `drizzle/`.
  Ask Lovable to change the schema.
- **Generated files.** Do not edit a file whose header says it is automatically
  generated.
- **AI gateway.** Keep model calls on Lovable's gateway, and keep
  `LOVABLE_API_KEY` out of browser code.
- **Connectors.** Lovable provides native connectors. `list_connectors` shows
  which are enabled; `add_connector` only returns the dashboard link. When a
  connector is enabled, calls go through the connector gateway and need
  `LOVABLE_API_KEY`. When Lovable does not provide one, users can bring their
  own key and store it in Secrets.
- **Secrets.** Lovable manages them. Do not put secret values in the repo.
<!-- LOVABLE:END -->

## Application architecture
- Render the legal footer once after Outlet in the root layout so legal information stays identical across pages without duplication.
- Resolve share metadata origins per request and build form, calendar and export links on the current site origin, so custom domains need no hardcoded URL replacements.
- Centralize robots directives in the browser-safe robots-policy module and apply them in the root head and server response wrapper so every page and error response shares the same policy.
- Do not read or write the retired page_visits table; retain a no-op track_visit function for compatibility with previously published clients.
- Keep event dates and input validation in a browser-safe domain module, with concrete rule tests, so the future server can reuse validation.
- Until Cloud is enabled, never accept registrations, simulate success, store personal data locally, or expose a demo admin dashboard; persistence and authorization must precede those features.
- Reference compressed event photography through asset pointers; the uploaded storefront is the primary cover.
- Registration capacity is enforced inside the `register_attendee` SQL function under an advisory lock; every public-schema function and table is callable only by the server role (no anon/authenticated access, even slot counts), so nothing is reachable directly through the Data API.
- Cancellation never deletes: `cancel_registration` sets status `cancelled` (+cancelled_at/by), then `promote_waitlist` fills the place in arrival order under the registration capacity lock and sets `promoted_at`. Email uniqueness only applies to non-cancelled rows. Reject grouped registrations in validation and on database insert to prevent guest priority manipulation.
- Admin access: username+password from server secrets issue a 12 h HMAC-signed httpOnly cookie identifying a private database session; every admin server fn calls requireOwner and checks session revocation. Logout revokes the database session before removing the cookie so copied cookies stop working; legacy cookies are rejected. No Lovable-owner fallback.
- All CSV exports use the browser-safe CSV serializer to quote cells and neutralize formula prefixes, including leading whitespace/control characters, so attendee input cannot become spreadsheet formulas.
