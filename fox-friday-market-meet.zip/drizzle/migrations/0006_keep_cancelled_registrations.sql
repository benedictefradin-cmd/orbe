ALTER TABLE public.registrations ADD COLUMN cancelled_at timestamptz, ADD COLUMN cancelled_by text;
ALTER TABLE public.registrations DROP CONSTRAINT registrations_email_key;
CREATE UNIQUE INDEX registrations_active_email_key ON public.registrations (email) WHERE status <> 'cancelled';

CREATE OR REPLACE FUNCTION public.cancel_registration(_token uuid)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public' AS $$
DECLARE n int;
BEGIN
  PERFORM pg_advisory_xact_lock(hashtext('fox_friday_registrations'));
  UPDATE registrations SET status = 'cancelled', cancelled_at = now(), cancelled_by = COALESCE(cancelled_by, 'participant')
  WHERE cancel_token = _token AND status <> 'cancelled';
  GET DIAGNOSTICS n = ROW_COUNT;
  IF n > 0 THEN PERFORM promote_waitlist(); END IF;
  RETURN n > 0;
END $$;

CREATE OR REPLACE FUNCTION public.admin_cancel_registration(_id uuid)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public' AS $$
DECLARE tok uuid;
BEGIN
  UPDATE registrations SET cancelled_by = 'organisatrice' WHERE id = _id AND status <> 'cancelled' RETURNING cancel_token INTO tok;
  IF tok IS NULL THEN RETURN false; END IF;
  RETURN cancel_registration(tok);
END $$;
REVOKE ALL ON FUNCTION public.admin_cancel_registration(uuid) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.admin_cancel_registration(uuid) TO service_role;

CREATE OR REPLACE FUNCTION public.cancel_by_contact(_email text, _phone text)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public' AS $$
DECLARE tok uuid;
BEGIN
  SELECT cancel_token INTO tok FROM registrations
  WHERE status <> 'cancelled' AND email = lower(trim(_email)) AND regexp_replace(phone, '\D', '', 'g') = regexp_replace(_phone, '\D', '', 'g');
  IF tok IS NULL THEN RETURN false; END IF;
  RETURN cancel_registration(tok);
END $$;

CREATE OR REPLACE FUNCTION public.register_attendee(r jsonb)
RETURNS text LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public' AS $$
DECLARE _slot text := r->>'slot'; _people int := CASE WHEN r->>'guest_email' IS NULL THEN 1 ELSE 2 END; _status text := 'confirmed';
BEGIN
  PERFORM pg_advisory_xact_lock(hashtext('fox_friday_registrations'));
  IF EXISTS (SELECT 1 FROM registrations WHERE email = lower(r->>'email') AND status <> 'cancelled') THEN RETURN 'duplicate'; END IF;
  IF r->>'workshop' = 'pot' THEN _slot := NULL;
  ELSIF slot_shoe_capacity(_slot) = 0 THEN RETURN 'invalid_slot';
  ELSIF NOT registration_fits(r->>'workshop', _slot, _people) THEN _status := 'waitlist';
  END IF;
  INSERT INTO registrations (status, workshop, slot, first_name, last_name, email, phone, member, guest_first_name, guest_last_name, guest_email, guest_member, stays_for_drinks, image_consent, event_consent, news_consent)
  VALUES (_status, r->>'workshop', _slot, r->>'first_name', r->>'last_name', lower(r->>'email'), r->>'phone', (r->>'member')::boolean, r->>'guest_first_name', r->>'guest_last_name', lower(r->>'guest_email'), (r->>'guest_member')::boolean, (r->>'stays_for_drinks')::boolean, (r->>'image_consent')::boolean, true, COALESCE((r->>'news_consent')::boolean, false));
  RETURN CASE WHEN _status = 'waitlist' THEN 'waitlisted' ELSE 'ok' END;
END $$;

CREATE OR REPLACE FUNCTION public.register_attendee_v2(r jsonb)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public' AS $$
DECLARE res text; tok uuid;
BEGIN
  res := register_attendee(r);
  IF res NOT IN ('ok','waitlisted') THEN RETURN jsonb_build_object('status', res); END IF;
  SELECT cancel_token INTO tok FROM registrations WHERE email = lower(r->>'email') AND status <> 'cancelled';
  RETURN jsonb_build_object('status', res, 'token', tok);
END $$;