CREATE TABLE public.registrations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at timestamptz NOT NULL DEFAULT now(),
  workshop text NOT NULL CHECK (workshop IN ('bichonnage','voir','pot')),
  slot text,
  first_name text NOT NULL,
  last_name text NOT NULL,
  email text NOT NULL,
  phone text NOT NULL,
  member boolean NOT NULL,
  guest_first_name text,
  guest_last_name text,
  guest_email text,
  guest_member boolean,
  stays_for_drinks boolean NOT NULL,
  image_consent boolean NOT NULL,
  event_consent boolean NOT NULL,
  news_consent boolean NOT NULL DEFAULT false,
  UNIQUE (email)
);
GRANT ALL ON public.registrations TO service_role;
ALTER TABLE public.registrations ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.slot_shoe_capacity(_slot text) RETURNS int LANGUAGE sql IMMUTABLE SET search_path = public AS $$
  SELECT CASE _slot WHEN '12 h 30' THEN 3 WHEN '13 h 10' THEN 3 WHEN '13 h 50' THEN 3 WHEN '14 h 30' THEN 3 WHEN '15 h 10' THEN 3 WHEN '15 h 50' THEN 3 WHEN '16 h 30' THEN 2 ELSE 0 END
$$;

CREATE OR REPLACE FUNCTION public.slot_availability()
RETURNS TABLE (slot text, shoe_care_left int, people_left int)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT s.slot,
    GREATEST(0, public.slot_shoe_capacity(s.slot) - COUNT(r.id) FILTER (WHERE r.workshop = 'bichonnage'))::int,
    GREATEST(0, 15 - COALESCE(SUM(CASE WHEN r.id IS NULL THEN 0 WHEN r.guest_email IS NULL THEN 1 ELSE 2 END), 0))::int
  FROM unnest(ARRAY['12 h 30','13 h 10','13 h 50','14 h 30','15 h 10','15 h 50','16 h 30']) AS s(slot)
  LEFT JOIN public.registrations r ON r.slot = s.slot
  GROUP BY s.slot ORDER BY s.slot
$$;
REVOKE ALL ON FUNCTION public.slot_availability() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.slot_availability() TO anon, authenticated, service_role;

CREATE OR REPLACE FUNCTION public.register_attendee(r jsonb)
RETURNS text LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _slot text := r->>'slot'; _people int := CASE WHEN r->>'guest_email' IS NULL THEN 1 ELSE 2 END; a record;
BEGIN
  PERFORM pg_advisory_xact_lock(hashtext('fox_friday_registrations'));
  IF EXISTS (SELECT 1 FROM registrations WHERE email = lower(r->>'email')) THEN RETURN 'duplicate'; END IF;
  IF r->>'workshop' <> 'pot' THEN
    SELECT * INTO a FROM slot_availability() s WHERE s.slot = _slot;
    IF a IS NULL THEN RETURN 'invalid_slot'; END IF;
    IF a.people_left < _people THEN RETURN 'slot_full'; END IF;
    IF r->>'workshop' = 'bichonnage' AND (a.shoe_care_left < 1 OR (SELECT COUNT(*) FROM registrations WHERE workshop='bichonnage') >= 20) THEN RETURN 'shoe_care_full'; END IF;
  ELSE _slot := NULL; END IF;
  INSERT INTO registrations (workshop, slot, first_name, last_name, email, phone, member, guest_first_name, guest_last_name, guest_email, guest_member, stays_for_drinks, image_consent, event_consent, news_consent)
  VALUES (r->>'workshop', _slot, r->>'first_name', r->>'last_name', lower(r->>'email'), r->>'phone', (r->>'member')::boolean, r->>'guest_first_name', r->>'guest_last_name', lower(r->>'guest_email'), (r->>'guest_member')::boolean, (r->>'stays_for_drinks')::boolean, (r->>'image_consent')::boolean, true, COALESCE((r->>'news_consent')::boolean, false));
  RETURN 'ok';
END $$;
REVOKE ALL ON FUNCTION public.register_attendee(jsonb) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.register_attendee(jsonb) TO service_role;