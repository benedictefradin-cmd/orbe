ALTER TABLE public.registrations ADD COLUMN status text NOT NULL DEFAULT 'confirmed' CHECK (status IN ('confirmed','waitlist'));
ALTER TABLE public.registrations ADD COLUMN promoted_at timestamptz;
ALTER TABLE public.registrations ADD COLUMN promotion_notified_at timestamptz;

CREATE OR REPLACE FUNCTION public.slot_availability()
RETURNS TABLE (slot text, shoe_care_left int, people_left int)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT s.slot,
    GREATEST(0, LEAST(public.slot_shoe_capacity(s.slot) - COUNT(r.id) FILTER (WHERE r.workshop = 'bichonnage'),
      20 - (SELECT COUNT(*) FROM registrations x WHERE x.workshop='bichonnage' AND x.status='confirmed')))::int,
    GREATEST(0, 15 - COALESCE(SUM(CASE WHEN r.id IS NULL THEN 0 WHEN r.guest_email IS NULL THEN 1 ELSE 2 END), 0))::int
  FROM unnest(ARRAY['12 h 30','13 h 10','13 h 50','14 h 30','15 h 10','15 h 50','16 h 30']) AS s(slot)
  LEFT JOIN public.registrations r ON r.slot = s.slot AND r.status = 'confirmed'
  GROUP BY s.slot ORDER BY s.slot
$$;

CREATE OR REPLACE FUNCTION public.registration_fits(_workshop text, _slot text, _people int)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT _workshop = 'pot' OR EXISTS (SELECT 1 FROM slot_availability() a WHERE a.slot = _slot
    AND a.people_left >= _people AND (_workshop <> 'bichonnage' OR a.shoe_care_left >= 1))
$$;
REVOKE ALL ON FUNCTION public.registration_fits(text, text, int) FROM PUBLIC, anon, authenticated;

CREATE OR REPLACE FUNCTION public.register_attendee(r jsonb)
RETURNS text LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _slot text := r->>'slot'; _people int := CASE WHEN r->>'guest_email' IS NULL THEN 1 ELSE 2 END; _status text := 'confirmed';
BEGIN
  PERFORM pg_advisory_xact_lock(hashtext('fox_friday_registrations'));
  IF EXISTS (SELECT 1 FROM registrations WHERE email = lower(r->>'email')) THEN RETURN 'duplicate'; END IF;
  IF r->>'workshop' = 'pot' THEN _slot := NULL;
  ELSIF slot_shoe_capacity(_slot) = 0 THEN RETURN 'invalid_slot';
  ELSIF NOT registration_fits(r->>'workshop', _slot, _people) THEN _status := 'waitlist';
  END IF;
  INSERT INTO registrations (status, workshop, slot, first_name, last_name, email, phone, member, guest_first_name, guest_last_name, guest_email, guest_member, stays_for_drinks, image_consent, event_consent, news_consent)
  VALUES (_status, r->>'workshop', _slot, r->>'first_name', r->>'last_name', lower(r->>'email'), r->>'phone', (r->>'member')::boolean, r->>'guest_first_name', r->>'guest_last_name', lower(r->>'guest_email'), (r->>'guest_member')::boolean, (r->>'stays_for_drinks')::boolean, (r->>'image_consent')::boolean, true, COALESCE((r->>'news_consent')::boolean, false));
  RETURN CASE WHEN _status = 'waitlist' THEN 'waitlisted' ELSE 'ok' END;
END $$;

CREATE OR REPLACE FUNCTION public.register_attendee_v2(r jsonb)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE res text; tok uuid;
BEGIN
  res := register_attendee(r);
  IF res NOT IN ('ok','waitlisted') THEN RETURN jsonb_build_object('status', res); END IF;
  SELECT cancel_token INTO tok FROM registrations WHERE email = lower(r->>'email');
  RETURN jsonb_build_object('status', res, 'token', tok);
END $$;

CREATE OR REPLACE FUNCTION public.promote_waitlist()
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE w record;
BEGIN
  FOR w IN SELECT * FROM registrations WHERE status = 'waitlist'
    ORDER BY (guest_email IS NOT NULL AND guest_member = false) DESC, created_at
  LOOP
    IF registration_fits(w.workshop, w.slot, CASE WHEN w.guest_email IS NULL THEN 1 ELSE 2 END) THEN
      UPDATE registrations SET status = 'confirmed', promoted_at = now() WHERE id = w.id;
    END IF;
  END LOOP;
END $$;
REVOKE ALL ON FUNCTION public.promote_waitlist() FROM PUBLIC, anon, authenticated;

CREATE OR REPLACE FUNCTION public.cancel_registration(_token uuid)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE n int;
BEGIN
  PERFORM pg_advisory_xact_lock(hashtext('fox_friday_registrations'));
  DELETE FROM registrations WHERE cancel_token = _token;
  GET DIAGNOSTICS n = ROW_COUNT;
  IF n > 0 THEN PERFORM promote_waitlist(); END IF;
  RETURN n > 0;
END $$;