CREATE TABLE public.page_visits (
  day date NOT NULL DEFAULT (now() AT TIME ZONE 'Europe/Paris')::date,
  path text NOT NULL,
  count integer NOT NULL DEFAULT 0,
  PRIMARY KEY (day, path)
);
GRANT ALL ON public.page_visits TO service_role;
ALTER TABLE public.page_visits ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.track_visit(_path text)
RETURNS void LANGUAGE sql SECURITY DEFINER SET search_path = public AS $$
  INSERT INTO public.page_visits (day, path, count)
  VALUES ((now() AT TIME ZONE 'Europe/Paris')::date, left(_path, 40), 1)
  ON CONFLICT (day, path) DO UPDATE SET count = page_visits.count + 1;
$$;
REVOKE ALL ON FUNCTION public.track_visit(text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.track_visit(text) TO service_role;