CREATE TABLE public.admin_owner (
  singleton boolean PRIMARY KEY DEFAULT true CHECK (singleton),
  lovable_user_id text NOT NULL,
  claimed_at timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.admin_owner TO service_role;
ALTER TABLE public.admin_owner ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.registrations ADD COLUMN checked_in_at timestamptz;