ALTER TABLE public.registrations ADD COLUMN cancel_token uuid NOT NULL DEFAULT gen_random_uuid() UNIQUE;

CREATE OR REPLACE FUNCTION public.register_attendee_v2(r jsonb)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE res text; tok uuid;
BEGIN
  res := register_attendee(r);
  IF res <> 'ok' THEN RETURN jsonb_build_object('status', res); END IF;
  SELECT cancel_token INTO tok FROM registrations WHERE email = lower(r->>'email');
  RETURN jsonb_build_object('status','ok','token',tok);
END $$;
REVOKE ALL ON FUNCTION public.register_attendee_v2(jsonb) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.register_attendee_v2(jsonb) TO service_role;

CREATE OR REPLACE FUNCTION public.cancel_registration(_token uuid)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE n int;
BEGIN
  DELETE FROM registrations WHERE cancel_token = _token;
  GET DIAGNOSTICS n = ROW_COUNT;
  RETURN n > 0;
END $$;
REVOKE ALL ON FUNCTION public.cancel_registration(uuid) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.cancel_registration(uuid) TO service_role;