COMMENT ON TABLE public.page_visits IS 'DEPRECATED: visitor analytics are provided by Lovable; no longer used by the app';
CREATE OR REPLACE FUNCTION public.track_visit(_path text) RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$ BEGIN RETURN; END; $$;
COMMENT ON FUNCTION public.track_visit(text) IS 'DEPRECATED: no-op retained for previously published clients';
REVOKE ALL ON FUNCTION public.track_visit(text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.track_visit(text) TO service_role;