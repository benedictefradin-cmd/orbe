REVOKE EXECUTE ON FUNCTION public.slot_availability() FROM anon, authenticated, PUBLIC;
REVOKE EXECUTE ON FUNCTION public.slot_shoe_capacity(text) FROM anon, authenticated, PUBLIC;
GRANT EXECUTE ON FUNCTION public.slot_availability() TO service_role;
GRANT EXECUTE ON FUNCTION public.slot_shoe_capacity(text) TO service_role;