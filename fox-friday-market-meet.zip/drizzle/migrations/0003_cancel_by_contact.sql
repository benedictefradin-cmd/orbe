CREATE OR REPLACE FUNCTION public.cancel_by_contact(_email text, _phone text)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE tok uuid;
BEGIN
  SELECT cancel_token INTO tok FROM registrations
  WHERE email = lower(trim(_email)) AND regexp_replace(phone, '\D', '', 'g') = regexp_replace(_phone, '\D', '', 'g');
  IF tok IS NULL THEN RETURN false; END IF;
  RETURN cancel_registration(tok);
END $$;
REVOKE ALL ON FUNCTION public.cancel_by_contact(text, text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.cancel_by_contact(text, text) TO service_role;