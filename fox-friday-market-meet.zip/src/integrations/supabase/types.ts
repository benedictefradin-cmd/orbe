export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.18"
  }
  public: {
    Tables: {
      admin_owner: {
        Row: {
          claimed_at: string
          lovable_user_id: string
          singleton: boolean
        }
        Insert: {
          claimed_at?: string
          lovable_user_id: string
          singleton?: boolean
        }
        Update: {
          claimed_at?: string
          lovable_user_id?: string
          singleton?: boolean
        }
        Relationships: []
      }
      admin_sessions: {
        Row: {
          expires_at: string
          id: string
          revoked_at: string | null
        }
        Insert: {
          expires_at: string
          id: string
          revoked_at?: string | null
        }
        Update: {
          expires_at?: string
          id?: string
          revoked_at?: string | null
        }
        Relationships: []
      }
      page_visits: {
        Row: {
          count: number
          day: string
          path: string
        }
        Insert: {
          count?: number
          day?: string
          path: string
        }
        Update: {
          count?: number
          day?: string
          path?: string
        }
        Relationships: []
      }
      registrations: {
        Row: {
          admin_comment: string | null
          cancel_token: string
          cancelled_at: string | null
          cancelled_by: string | null
          checked_in_at: string | null
          created_at: string
          email: string
          email_sent_at: string | null
          event_consent: boolean
          first_name: string
          guest_email: string | null
          guest_first_name: string | null
          guest_last_name: string | null
          guest_member: boolean | null
          id: string
          image_consent: boolean
          last_name: string
          member: boolean
          news_consent: boolean
          phone: string
          promoted_at: string | null
          promotion_notified_at: string | null
          slot: string | null
          status: string
          stays_for_drinks: boolean
          workshop: string
        }
        Insert: {
          admin_comment?: string | null
          cancel_token?: string
          cancelled_at?: string | null
          cancelled_by?: string | null
          checked_in_at?: string | null
          created_at?: string
          email: string
          email_sent_at?: string | null
          event_consent: boolean
          first_name: string
          guest_email?: string | null
          guest_first_name?: string | null
          guest_last_name?: string | null
          guest_member?: boolean | null
          id?: string
          image_consent: boolean
          last_name: string
          member: boolean
          news_consent?: boolean
          phone: string
          promoted_at?: string | null
          promotion_notified_at?: string | null
          slot?: string | null
          status?: string
          stays_for_drinks: boolean
          workshop: string
        }
        Update: {
          admin_comment?: string | null
          cancel_token?: string
          cancelled_at?: string | null
          cancelled_by?: string | null
          checked_in_at?: string | null
          created_at?: string
          email?: string
          email_sent_at?: string | null
          event_consent?: boolean
          first_name?: string
          guest_email?: string | null
          guest_first_name?: string | null
          guest_last_name?: string | null
          guest_member?: boolean | null
          id?: string
          image_consent?: boolean
          last_name?: string
          member?: boolean
          news_consent?: boolean
          phone?: string
          promoted_at?: string | null
          promotion_notified_at?: string | null
          slot?: string | null
          status?: string
          stays_for_drinks?: boolean
          workshop?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      admin_cancel_registration: { Args: { _id: string }; Returns: boolean }
      cancel_by_contact: {
        Args: { _email: string; _phone: string }
        Returns: boolean
      }
      cancel_registration: { Args: { _token: string }; Returns: boolean }
      promote_waitlist: { Args: never; Returns: undefined }
      register_attendee: { Args: { r: Json }; Returns: string }
      register_attendee_v2: { Args: { r: Json }; Returns: Json }
      registration_fits: {
        Args: { _people: number; _slot: string; _workshop: string }
        Returns: boolean
      }
      slot_availability: {
        Args: never
        Returns: {
          people_left: number
          shoe_care_left: number
          slot: string
        }[]
      }
      slot_shoe_capacity: { Args: { _slot: string }; Returns: number }
      track_visit: { Args: { _path: string }; Returns: undefined }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
