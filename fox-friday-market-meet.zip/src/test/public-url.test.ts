import { describe, expect, it } from "vitest";
import { siteUrl } from "@/lib/public-url";

describe("links follow the site's domain", () => {
  it("shares the form on the current custom domain", () => {
    expect(siteUrl("https://evenement.example.org", "/inscription")).toBe("https://evenement.example.org/inscription");
  });
  it("keeps the personal cancellation token on the same domain", () => {
    expect(siteUrl("https://evenement.example.org", "/annuler/person-token")).toBe("https://evenement.example.org/annuler/person-token");
  });
});