import { describe, expect, it } from "vitest";
import { csvCell, serializeCsv } from "@/lib/csv";

describe("CSV formula protection", () => {
  it.each(["=1+1", "+1+1", "-1+1", "@SUM(1)", "  =1+1", "\t=1+1", "\r=1+1", "\n=1+1", "\u0000=1+1", "＝1+1", "＋1+1", "－1+1", "＠SUM(1)"])("forces %j to literal text", (input) => {
    expect(csvCell(input)).toBe(`"'${input}"`);
  });

  it("protects phone numbers and comments as well as names", () => {
    expect(serializeCsv([["=1+1", "+33612345678", "@SUM(1)"]])).toBe('"\'=1+1";"\'+33612345678";"\'@SUM(1)"');
  });

  it("escapes quotes, separators and embedded lines without extra cells", () => {
    expect(csvCell('Marie; "Bonjour"\nSuite')).toBe('"Marie; ""Bonjour""\nSuite"');
    expect(csvCell("Marie-Bénédicte")).toBe('"Marie-Bénédicte"');
    expect(csvCell(null)).toBe('""');
  });
});