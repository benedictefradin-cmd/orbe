import { beforeEach, describe, expect, it, vi } from "vitest";

const state = vi.hoisted(() => ({ cookie: "", rows: new Map<string, { expires_at: string; revoked_at: string | null }>(), failRevoke: false }));
vi.mock("@tanstack/react-start/server", () => ({
  getCookie: () => state.cookie,
  setCookie: (_name: string, value: string) => { state.cookie = value; },
  deleteCookie: () => { state.cookie = ""; },
}));
vi.mock("@/integrations/supabase/client.server", () => ({ supabaseAdmin: { from: () => ({
  insert: async (row: { id: string; expires_at: string }) => { state.rows.set(row.id, { expires_at: row.expires_at, revoked_at: null }); return { error: null }; },
  update: (patch: { revoked_at: string }) => ({ eq: async (_key: string, id: string) => {
    if (state.failRevoke) return { error: new Error("Unavailable") };
    const row = state.rows.get(id);
    if (row) row.revoked_at = patch.revoked_at;
    return { error: null };
  } }),
  select: () => ({ eq: (_key: string, id: string) => ({ maybeSingle: async () => ({ data: state.rows.get(id) ?? null, error: null }) }) }),
}) } }));
import { endAdminSession, hasAdminSession, startAdminSession } from "@/lib/admin-session.server";

describe("Administrator session revocation", () => {
  beforeEach(() => {
    state.cookie = ""; state.rows.clear(); state.failRevoke = false;
    vi.stubEnv("ADMIN_SESSION_SECRET", "test-only-session-secret");
  });
  it("rejects a copied cookie immediately after logout", async () => {
    await startAdminSession();
    const copied = state.cookie;
    expect(await hasAdminSession()).toBe(true);
    await endAdminSession();
    expect(state.cookie).toBe("");
    state.cookie = copied;
    expect(await hasAdminSession()).toBe(false);
  });
  it("rejects legacy and tampered cookies", async () => {
    state.cookie = "9999999999.legacy-signature";
    expect(await hasAdminSession()).toBe(false);
    await startAdminSession();
    state.cookie += "tampered";
    expect(await hasAdminSession()).toBe(false);
  });
  it("does not report logout success if revocation fails", async () => {
    await startAdminSession();
    state.failRevoke = true;
    await expect(endAdminSession()).rejects.toThrow("Déconnexion impossible");
    expect(state.cookie).not.toBe("");
  });
});