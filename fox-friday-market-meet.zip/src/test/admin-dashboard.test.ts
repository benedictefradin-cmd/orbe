import { describe, expect, it } from "vitest";
import { countWorkshopObservers } from "@/components/admin-dashboard";

describe("Ateliers observer count", () => {
  it("counts two observers separately from two shoe-care attendees and one drinks attendee", () => {
    const rows = ["bichonnage", "bichonnage", "voir", "voir", "pot"].map((workshop) => ({
      status: "confirmed", workshop, guest_email: null,
    }));
    expect(countWorkshopObservers(rows)).toBe(2);
  });

  it("excludes cancelled and waitlisted observers", () => {
    const rows = ["confirmed", "waitlist", "cancelled"].map((status) => ({
      status, workshop: "voir", guest_email: null,
    }));
    expect(countWorkshopObservers(rows)).toBe(1);
  });
});