import { describe, expect, it } from "vitest";
import { EVENT, registrationWindow, registrationSchema } from "@/lib/fox-friday";

const valid = { firstName: "Camille", lastName: "Test", email: "camille@example.com", member: "oui", phone: "0601020304", workshop: "bichonnage", slot: "12 h 30", staysForDrinks: true, imageConsent: false, eventConsent: true };
describe("Fox Friday registration rules", () => {
  it("opens on November 20 at 12:55 in Paris", () => {
    expect(registrationWindow(new Date("2026-11-20T11:54:59Z"))).toBe("upcoming");
    expect(registrationWindow(new Date("2026-11-20T11:55:00Z"))).toBe("open");
  });
  it("closes on November 25 at noon in Paris", () => {
    expect(registrationWindow(new Date("2026-11-25T10:59:59Z"))).toBe("open");
    expect(registrationWindow(new Date("2026-11-25T11:00:00Z"))).toBe("closed");
  });
  it("offers exactly seven workshop start times", () => {
    expect(EVENT.times).toEqual(["12 h 30", "13 h 10", "13 h 50", "14 h 30", "15 h 10", "15 h 50", "16 h 30"]);
  });
  it("requires a valid slot for workshops", () => {
    expect(registrationSchema.safeParse(valid).success).toBe(true);
    expect(registrationSchema.safeParse({ ...valid, slot: "17 h 30" }).success).toBe(false);
  });
  it("does not require a slot for drinks", () => {
    expect(registrationSchema.safeParse({ ...valid, workshop: "pot", slot: "" }).success).toBe(true);
  });
  it("rejects grouped registrations even with a different guest email", () => {
    expect(registrationSchema.safeParse(valid).success).toBe(true);
    expect(registrationSchema.safeParse({ ...valid, guest: { firstName: "Alex", lastName: "Test", email: "alex@example.com", member: "pas-encore" } }).success).toBe(false);
  });
  it("requires an event consent", () => {
    expect(registrationSchema.safeParse({ ...valid, eventConsent: false }).success).toBe(false);
  });
  it("does not default to contact consent", () => {
    expect(registrationSchema.parse(valid).newsConsent).toBe(false);
  });
  it("accepts refusal of photography", () => {
    expect(registrationSchema.parse(valid).imageConsent).toBe(false);
  });
  it("requires the main participant phone", () => {
    expect(registrationSchema.safeParse({ ...valid, phone: "" }).success).toBe(false);
  });
});
import { CAPACITY, slotRemaining } from "@/lib/fox-friday";
describe("Fox Friday capacity", () => {
  it("offers 20 shoe-care sessions in total", () => {
    expect(Object.values(CAPACITY.shoeCarePerSlot).reduce((a, b) => a + b, 0)).toBe(20);
  });
  it("caps each slot at 15 people including +1", () => {
    expect(slotRemaining("12 h 30", { shoeCare: 0, people: 14 }).people).toBe(1);
    expect(slotRemaining("12 h 30", { shoeCare: 3, people: 16 })).toEqual({ shoeCare: 0, people: 0 });
  });
});
describe("Fox Friday phone and consents", () => {
  it("requires at least 10 digits", () => {
    expect(registrationSchema.safeParse({ ...valid, phone: "......" }).success).toBe(false);
    expect(registrationSchema.safeParse({ ...valid, phone: "123456" }).success).toBe(false);
    expect(registrationSchema.safeParse({ ...valid, phone: "06 12.34-56 (78)" }).success).toBe(true);
    expect(registrationSchema.safeParse({ ...valid, phone: "+33612345678" }).success).toBe(true);
  });
  it("uses a single French phone message", () => {
    const r = registrationSchema.safeParse({ ...valid, phone: "123" });
    expect(r.success ? "" : r.error.issues[0]?.message).toBe("Indiquez un numéro de téléphone valide.");
  });
  it("keeps news consent independent from event consent", () => {
    expect(registrationSchema.parse({ ...valid, newsConsent: true }).newsConsent).toBe(true);
    expect(registrationSchema.parse(valid).newsConsent).toBe(false);
  });
  it("shows French messages for too long names", () => {
    const r = registrationSchema.safeParse({ ...valid, firstName: "a".repeat(101) });
    expect(r.success ? "" : r.error.issues[0]?.message).toBe("Ce champ doit contenir au plus 100 caractères.");
  });
});
