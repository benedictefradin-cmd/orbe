import { describe, expect, it } from "vitest";
import { blockResponseIndexing } from "@/lib/robots-policy";

describe("site-wide indexing restrictions", () => {
  it.each([200, 302, 404, 500])("blocks indexing of HTTP %i responses", async (status) => {
    const response = blockResponseIndexing(new Response("Fox Friday", {
      status,
      headers: { "Content-Type": "text/html", "Set-Cookie": "example=value; HttpOnly" },
    }));
    expect(response.headers.get("X-Robots-Tag")).toBe("noindex, nofollow, noarchive, nosnippet, noimageindex");
    expect(response.status).toBe(status);
    expect(response.headers.get("Set-Cookie")).toBe("example=value; HttpOnly");
    expect(await response.text()).toBe("Fox Friday");
  });
});