import { z } from "zod";

/** Messages zod en français : aucun message anglais par défaut ne doit s'afficher. */
z.setErrorMap((issue, ctx) => {
  switch (issue.code) {
    case "too_small": return { message: issue.type === "string" ? `Ce champ doit contenir au moins ${String(issue.minimum)} caractères.` : "Valeur trop petite." };
    case "too_big": return { message: issue.type === "string" ? `Ce champ doit contenir au plus ${String(issue.maximum)} caractères.` : "Valeur trop grande." };
    case "invalid_string": return { message: issue.validation === "email" ? "Indiquez une adresse email valide." : "Format invalide." };
    case "invalid_type": return { message: issue.received === "undefined" ? "Ce champ est obligatoire." : "Valeur invalide." };
    case "invalid_enum_value": case "invalid_literal": return { message: "Choix invalide." };
    default: return { message: ctx.defaultError && "Vérifiez le formulaire." };
  }
});

/** Au moins 10 chiffres une fois espaces, points, tirets et parenthèses retirés ; « + » en tête accepté. */
export const PHONE_MESSAGE = "Indiquez un numéro de téléphone valide.";
export function isValidPhone(raw: string): boolean {
  const compact = raw.trim().replace(/[\s.()\-]/g, "");
  return /^\+?\d{10,}$/.test(compact);
}

export const EVENT = {
  opensAt: "2026-11-20T12:55:00+01:00",
  closesAt: "2026-11-25T12:00:00+01:00",
  date: "2026-11-27",
  times: ["12 h 30", "13 h 10", "13 h 50", "14 h 30", "15 h 10", "15 h 50", "16 h 30"],
} as const;
export type Workshop = "bichonnage" | "voir" | "pot";
export type RegistrationWindow = "upcoming" | "open" | "closed";
export function registrationWindow(now: Date): RegistrationWindow {
  if (now.getTime() < new Date(EVENT.opensAt).getTime()) return "upcoming";
  if (now.getTime() >= new Date(EVENT.closesAt).getTime()) return "closed";
  return "open";
}

const person = z.object({
  firstName: z.string().trim().min(1, "Indiquez votre prénom.").max(100),
  lastName: z.string().trim().min(1, "Indiquez votre nom.").max(100),
  email: z.string().trim().toLowerCase().email("Indiquez une adresse email valide.").max(254),
  member: z.enum(["oui", "pas-encore"]),
});
export const registrationSchema = person.extend({
  phone: z.string({ errorMap: () => ({ message: PHONE_MESSAGE }) }).trim().max(30, PHONE_MESSAGE).refine(isValidPhone, PHONE_MESSAGE),
  workshop: z.enum(["bichonnage", "voir", "pot"]),
  slot: z.string(),
  guest: z.never().optional(),
  staysForDrinks: z.boolean(),
  imageConsent: z.boolean(),
  eventConsent: z.literal(true, { errorMap: () => ({ message: "Votre accord est nécessaire pour les informations de l’évènement." }) }),
  newsConsent: z.boolean().default(false),
}).superRefine((value, ctx) => {
  if (value.workshop !== "pot" && !EVENT.times.some((time) => time === value.slot)) {
    ctx.addIssue({ code: "custom", path: ["slot"], message: "Choisissez un créneau." });
  }
});
export const EVENT_CONSENT = "J'accepte que Green-Got utilise mes coordonnées pour m'envoyer les informations de cet évènement";
export const NEWS_CONSENT = "J'accepte de recevoir les invitations aux prochains évènements Green-Got";
/** Capacité : 20 bichonnages au total (3 par créneau, 2 au dernier), 15 personnes max par créneau, accompagnants compris. */
export const CAPACITY = {
  totalShoeCare: 20,
  shoeCarePerSlot: { "12 h 30": 3, "13 h 10": 3, "13 h 50": 3, "14 h 30": 3, "15 h 10": 3, "15 h 50": 3, "16 h 30": 2 } as Record<string, number>,
  peoplePerSlot: 15,
  /** Jauge indicative du pot (personnes, +1 compris). */
  drinks: 150,
};
/** Places restantes d'un créneau ; `guests` compte chaque personne, +1 compris. */
export function slotRemaining(slot: string, booked: { shoeCare: number; people: number }) {
  return {
    shoeCare: Math.max(0, (CAPACITY.shoeCarePerSlot[slot] ?? 0) - booked.shoeCare),
    people: Math.max(0, CAPACITY.peoplePerSlot - booked.people),
  };
}
