/** Quote every cell and force formula-like input to remain literal text. */
export function csvCell(value: unknown): string {
  const text = String(value ?? "");
  const formulaLike = /^[\s\u0000-\u001f\u007f]*[=+@\-＝＋－＠]/u.test(text);
  const startsWithControl = /^[\t\r\n]/u.test(text);
  const safe = formulaLike || startsWithControl ? `'${text}` : text;
  return `"${safe.replace(/"/g, '""')}"`;
}

export function serializeCsv(rows: readonly (readonly unknown[])[]): string {
  return rows.map((row) => row.map(csvCell).join(";")).join("\n");
}