import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { isValidPhone, PHONE_MESSAGE, registrationSchema, registrationWindow } from "@/lib/fox-friday";

export type SlotAvailability = { slot: string; shoeCareLeft: number; peopleLeft: number };

export const getAvailability = createServerFn({ method: "GET" }).handler(async (): Promise<SlotAvailability[]> => {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data, error } = await supabaseAdmin.rpc("slot_availability");
  if (error) throw new Error("Disponibilités indisponibles");
  return (data ?? []).map((row) => ({ slot: row.slot, shoeCareLeft: row.shoe_care_left, peopleLeft: row.people_left }));
});

const MESSAGES: Record<string, string> = {
  duplicate: "Cette adresse email est déjà inscrite.",
  slot_full: "Ce créneau est complet. Choisissez-en un autre.",
  shoe_care_full: "Plus de bichonnage disponible sur ce créneau. Choisissez-en un autre ou venez voir le bichonnage.",
  invalid_slot: "Choisissez un créneau.",
};

export const submitRegistration = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => registrationSchema.parse(input))
  .handler(async ({ data }): Promise<{ ok: true; token: string; waitlisted: boolean } | { ok: false; message: string }> => {
    if (registrationWindow(new Date()) !== "open") return { ok: false, message: "Les inscriptions ne sont pas ouvertes." };
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: result, error } = await supabaseAdmin.rpc("register_attendee_v2", {
      r: {
        workshop: data.workshop, slot: data.workshop === "pot" ? null : data.slot,
        first_name: data.firstName, last_name: data.lastName, email: data.email, phone: data.phone, member: data.member === "oui",
        stays_for_drinks: data.workshop === "pot" ? true : data.staysForDrinks, image_consent: data.imageConsent,
        news_consent: data.newsConsent,
      },
    });
    if (error) return { ok: false, message: "L’inscription n’a pas pu être enregistrée. Réessayez ou écrivez à impact@green-got.com." };
    const r = result as { status: string; token?: string };
    if ((r.status !== "ok" && r.status !== "waitlisted") || !r.token) return { ok: false, message: MESSAGES[r.status] ?? "Inscription impossible." };
    return { ok: true, token: r.token, waitlisted: r.status === "waitlisted" };
  });

export const cancelRegistration = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => z.object({ token: z.string().uuid() }).parse(input))
  .handler(async ({ data }): Promise<{ ok: boolean }> => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: ok, error } = await supabaseAdmin.rpc("cancel_registration", { _token: data.token });
    if (error) throw new Error("Annulation impossible");
    return { ok: ok === true };
  });

export const cancelByContact = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => z.object({ email: z.string().trim().email().max(254), phone: z.string().trim().max(30).refine(isValidPhone, PHONE_MESSAGE) }).parse(input))
  .handler(async ({ data }): Promise<{ ok: boolean }> => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: ok, error } = await supabaseAdmin.rpc("cancel_by_contact", { _email: data.email, _phone: data.phone });
    if (error) throw new Error("Annulation impossible");
    return { ok: ok === true };
  });
