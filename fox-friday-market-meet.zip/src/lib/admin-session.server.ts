import { getCookie, setCookie, deleteCookie } from "@tanstack/react-start/server";

const COOKIE = "ff_admin";
const MAX_AGE = 60 * 60 * 12; // 12 h

async function sign(payload: string) {
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(process.env["ADMIN_SESSION_SECRET"] ?? ""), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const sig = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(payload));
  return btoa(String.fromCharCode(...new Uint8Array(sig))).replace(/[+/=]/g, (c) => (c === "+" ? "-" : c === "/" ? "_" : ""));
}

function safeEqual(a: string, b: string) {
  if (a.length !== b.length) return false;
  let d = 0;
  for (let i = 0; i < a.length; i++) d |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return d === 0;
}

export async function checkCredentials(user: string, pass: string) {
  const u = process.env["ADMIN_USERNAME"], p = process.env["ADMIN_PASSWORD"];
  if (!u || !p || !process.env["ADMIN_SESSION_SECRET"]) return false;
  const [a, b] = await Promise.all([sign(user), sign(u)]);
  const [c, d] = await Promise.all([sign(pass), sign(p)]);
  return safeEqual(a, b) && safeEqual(c, d);
}

export async function startAdminSession() {
  if (!process.env["ADMIN_SESSION_SECRET"]) throw new Error("Session indisponible");
  const exp = String(Math.floor(Date.now() / 1000) + MAX_AGE);
  const id = crypto.randomUUID();
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { error } = await supabaseAdmin.from("admin_sessions").insert({ id, expires_at: new Date(Number(exp) * 1000).toISOString() });
  if (error) throw new Error("Session indisponible");
  const payload = `${exp}.${id}`;
  setCookie(COOKIE, `${payload}.${await sign(payload)}`, { httpOnly: true, secure: true, sameSite: "lax", path: "/", maxAge: MAX_AGE });
}

async function readSignedSession() {
  const v = getCookie(COOKIE);
  if (!v || !process.env["ADMIN_SESSION_SECRET"]) return null;
  const parts = v.split(".");
  const [exp = "", id = "", sig = ""] = parts;
  if (parts.length !== 3 || !/^\d+$/.test(exp) || Number(exp) <= Date.now() / 1000 || !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(id)) return null;
  if (!safeEqual(sig, await sign(`${exp}.${id}`))) return null;
  return { id, exp };
}

export async function endAdminSession() {
  const session = await readSignedSession();
  if (session) {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.from("admin_sessions").update({ revoked_at: new Date().toISOString() }).eq("id", session.id);
    if (error) throw new Error("Déconnexion impossible, réessayez.");
  }
  deleteCookie(COOKIE, { path: "/" });
}

export async function hasAdminSession() {
  const session = await readSignedSession();
  if (!session) return false;
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data, error } = await supabaseAdmin.from("admin_sessions").select("expires_at, revoked_at").eq("id", session.id).maybeSingle();
  return !error && !!data && data.revoked_at === null && new Date(data.expires_at).getTime() > Date.now();
}
