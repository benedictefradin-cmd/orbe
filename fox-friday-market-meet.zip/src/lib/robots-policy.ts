export const ROBOTS_POLICY = "noindex, nofollow, noarchive, nosnippet, noimageindex";

export function blockResponseIndexing(response: Response): Response {
  const headers = new Headers(response.headers);
  headers.set("X-Robots-Tag", ROBOTS_POLICY);
  return new Response(response.body, {
    status: response.status,
    statusText: response.statusText,
    headers,
  });
}