import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

/** Accès admin : uniquement la session signée obtenue avec l’identifiant et le mot de passe secrets. */
async function requireOwner() {
  const { hasAdminSession } = await import("@/lib/admin-session.server");
  if (!(await hasAdminSession())) return { admin: null, status: "anonymous" as const };
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  return { admin: supabaseAdmin, status: "ok" as const };
}

export const getAdminData = createServerFn({ method: "GET" }).handler(async () => {
  const { admin, status } = await requireOwner();
  if (!admin) return { status, rows: [] };
  const { data, error } = await admin.from("registrations")
    .select("id, created_at, status, workshop, slot, first_name, last_name, email, phone, member, guest_first_name, guest_last_name, guest_email, guest_member, stays_for_drinks, image_consent, news_consent, promoted_at, promotion_notified_at, checked_in_at, cancel_token, cancelled_at, cancelled_by, email_sent_at, admin_comment")
    .order("slot", { nullsFirst: false }).order("created_at");
  if (error) throw new Error("Lecture impossible");
  return { status, rows: data ?? [] };
});

export const setCheckIn = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => z.object({ id: z.string().uuid(), arrived: z.boolean() }).parse(input))
  .handler(async ({ data }) => {
    const { admin } = await requireOwner();
    if (!admin) throw new Error("Accès refusé");
    const { error } = await admin.from("registrations").update({ checked_in_at: data.arrived ? new Date().toISOString() : null }).eq("id", data.id);
    if (error) throw new Error("Mise à jour impossible");
    return { ok: true };
  });

export const adminCancel = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data }) => {
    const { admin } = await requireOwner();
    if (!admin) throw new Error("Accès refusé");
    const { error } = await admin.rpc("admin_cancel_registration", { _id: data.id });
    if (error) throw new Error("Annulation impossible");
    return { ok: true };
  });

export const markNotified = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data }) => {
    const { admin } = await requireOwner();
    if (!admin) throw new Error("Accès refusé");
    const { error } = await admin.from("registrations").update({ promotion_notified_at: new Date().toISOString() }).eq("id", data.id);
    if (error) throw new Error("Mise à jour impossible");
    return { ok: true };
  });

export const adminLogin = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => z.object({ user: z.string().max(100), pass: z.string().max(200) }).parse(input))
  .handler(async ({ data }) => {
    const { checkCredentials, startAdminSession } = await import("@/lib/admin-session.server");
    if (!(await checkCredentials(data.user.trim(), data.pass))) {
      await new Promise((r) => setTimeout(r, 800));
      return { ok: false };
    }
    await startAdminSession();
    return { ok: true };
  });

export const adminLogout = createServerFn({ method: "POST" }).handler(async () => {
  const { endAdminSession } = await import("@/lib/admin-session.server");
  await endAdminSession();
  return { ok: true };
});

export const setFollowUp = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => z.object({ id: z.string().uuid(), emailSent: z.boolean().optional(), comment: z.string().max(1000).optional() }).parse(input))
  .handler(async ({ data }) => {
    const { admin } = await requireOwner();
    if (!admin) throw new Error("Accès refusé");
    const patch: { email_sent_at?: string | null; admin_comment?: string | null } = {};
    if (data.emailSent !== undefined) patch.email_sent_at = data.emailSent ? new Date().toISOString() : null;
    if (data.comment !== undefined) patch.admin_comment = data.comment.trim() || null;
    const { error } = await admin.from("registrations").update(patch).eq("id", data.id);
    if (error) throw new Error("Mise à jour impossible");
    return { ok: true };
  });
