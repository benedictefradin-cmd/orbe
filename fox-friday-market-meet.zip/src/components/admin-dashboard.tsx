import { useEffect, useState, type CSSProperties } from "react";
import { Eye, Footprints, Lock, Trophy, Users, Wine } from "lucide-react";
import { CAPACITY } from "@/lib/fox-friday";

type Row = { status: string; workshop: string; slot: string | null; created_at: string; member: boolean | null; guest_email: string | null; guest_member: boolean | null; stays_for_drinks: boolean | null; checked_in_at: string | null };

export function countWorkshopObservers(rows: ReadonlyArray<Pick<Row, "status" | "workshop" | "guest_email">>) {
  return rows.filter((r) => r.status === "confirmed" && r.workshop === "voir").reduce((n, r) => n + (r.guest_email ? 2 : 1), 0);
}

function useCountUp(target: number, ms = 900) {
  const [v, setV] = useState(0);
  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) { setV(target); return; }
    let raf = 0; const start = performance.now();
    const step = (t: number) => { const p = Math.min(1, (t - start) / ms); setV(Math.round(target * (1 - Math.pow(1 - p, 3)))); if (p < 1) raf = requestAnimationFrame(step); };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [target, ms]);
  return v;
}

const delay = (i: number) => ({ animationDelay: `${i * 70}ms` }) as CSSProperties;

function Kpi({ icon, label, value, suffix = "", sub, i }: { icon: React.ReactNode; label: string; value: number; suffix?: string; sub?: string; i: number }) {
  const n = useCountUp(value);
  return <div className="dash-card dash-in" style={delay(i)}>
    <div className="dash-label">{icon}{label}</div>
    <div className="dash-number">{n}{suffix}</div>
    {sub && <div className="dash-sub">{sub}</div>}
  </div>;
}

function Bar({ value, max, i = 0 }: { value: number; max: number; i?: number }) {
  const pct = max ? Math.min(100, (value / max) * 100) : 0;
  return <div className="dash-track"><div className={`dash-fill ${pct >= 100 ? "is-full" : pct >= 75 ? "is-hot" : ""}`} style={{ width: `${pct}%`, ...delay(i) }}/></div>;
}

function Gauge({ label, icon, value, max, sub, i }: { label: string; icon: React.ReactNode; value: number; max: number; sub?: string; i: number }) {
  const n = useCountUp(value);
  const pct = max ? Math.min(100, Math.round((value / max) * 100)) : 0;
  const r = 42, c = 2 * Math.PI * r;
  return <div className="dash-card dash-in flex items-center gap-4" style={delay(i)}>
    <svg viewBox="0 0 100 100" className="dash-ring" aria-hidden="true">
      <circle cx="50" cy="50" r={r} className="dash-ring-bg"/>
      <circle cx="50" cy="50" r={r} className={`dash-ring-fg ${pct >= 90 ? "is-full" : ""}`} strokeDasharray={c} style={{ ["--ring-to" as string]: `${c * (1 - pct / 100)}`, ["--ring-from" as string]: `${c}`, ...delay(i) }}/>
      <text x="50" y="56" textAnchor="middle" className="dash-ring-text">{pct}%</text>
    </svg>
    <div><div className="dash-label">{icon}{label}</div><div className="dash-number">{n}<span className="dash-of"> / {max}</span></div>{sub && <div className="dash-sub">{sub}</div>}</div>
  </div>;
}

export function AdminDashboard({ rows }: { rows: Row[] }) {
  const confirmed = rows.filter((r) => r.status === "confirmed");
  const size = (r: Row) => (r.guest_email ? 2 : 1);
  const people = confirmed.reduce((n, r) => n + size(r), 0);
  const members = confirmed.reduce((n, r) => n + (r.member ? 1 : 0) + (r.guest_email && r.guest_member ? 1 : 0), 0);
  const shoe = confirmed.filter((r) => r.workshop === "bichonnage").length;
  const watchers = countWorkshopObservers(rows);
  const slots = Object.keys(CAPACITY.shoeCarePerSlot);
  const drinks = confirmed.filter((r) => r.workshop === "pot" || r.stays_for_drinks).reduce((n, r) => n + size(r), 0);
  const waitlist = rows.filter((r) => r.status === "waitlist").length;
  const cancelled = rows.filter((r) => r.status === "cancelled").length;
  const arrived = confirmed.filter((r) => r.checked_in_at).reduce((n, r) => n + size(r), 0);


  // Créneaux : remplissage et moment où ils ont été bloqués
  const slotStats = slots.map((slot) => {
    const list = confirmed.filter((r) => r.slot === slot).sort((a, b) => a.created_at.localeCompare(b.created_at));
    const shoeCap = CAPACITY.shoeCarePerSlot[slot] ?? 0;
    let s = 0, p = 0, shoeFullAt: string | null = null, fullAt: string | null = null;
    for (const r of list) {
      if (r.workshop === "bichonnage") s++;
      p += size(r);
      if (!shoeFullAt && s >= shoeCap) shoeFullAt = r.created_at;
      if (!fullAt && p >= CAPACITY.peoplePerSlot) fullAt = r.created_at;
    }
    return { slot, shoe: s, shoeCap, people: p, shoeFullAt, fullAt, fill: p / CAPACITY.peoplePerSlot + s / Math.max(1, shoeCap) };
  });
  const blocked = slotStats.filter((s) => s.shoeFullAt).sort((a, b) => (a.shoeFullAt ?? "").localeCompare(b.shoeFullAt ?? ""));
  const ranking = [...slotStats].sort((a, b) => (a.shoeFullAt && b.shoeFullAt ? a.shoeFullAt.localeCompare(b.shoeFullAt) : a.shoeFullAt ? -1 : b.shoeFullAt ? 1 : b.fill - a.fill)).filter((s) => s.people > 0).slice(0, 3);

  // Courbe : inscriptions par jour
  const days = [...new Set(rows.map((r) => new Date(r.created_at).toLocaleDateString("sv-SE", { timeZone: "Europe/Paris" })))].sort().slice(-14);
  const perDay = days.map((d) => ({ d, r: rows.filter((x) => new Date(x.created_at).toLocaleDateString("sv-SE", { timeZone: "Europe/Paris" }) === d).length }));
  const maxDay = Math.max(1, ...perDay.map((x) => x.r));
  const fmt = (iso: string) => new Date(iso).toLocaleString("fr-FR", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit", timeZone: "Europe/Paris" });

  return <section className="dashboard my-8" aria-label="Tableau de bord">
    <div className="grid gap-3 grid-cols-2">
      <Kpi i={1} icon={<Users size={14}/>} label="Inscriptions" value={confirmed.length} sub={`${people} personnes · ${waitlist} en attente · ${cancelled} annulées`}/>
      <Kpi i={3} icon={<Users size={14}/>} label="Arrivés le jour J" value={arrived} sub={`sur ${people} attendus`}/>
    </div>

    <div className="dash-card dash-in mt-3" style={delay(4)}>
      <div className="dash-label"><Users size={14}/>Membres / non membres</div>
      <div className="dash-split mt-3"><div className="dash-split-a" style={{ flexGrow: members || 0.0001 }}><span>{members} membres</span></div><div className="dash-split-b" style={{ flexGrow: people - members || 0.0001 }}><span>{people - members} non membres</span></div></div>
    </div>

    <div className="grid gap-3 md:grid-cols-3 mt-3">
      <Gauge i={5} icon={<Footprints size={14}/>} label="Bichonnage" value={shoe} max={CAPACITY.totalShoeCare} sub="paires"/>
      <Gauge i={6} icon={<Eye size={14}/>} label="Ateliers" value={watchers} max={slots.length * CAPACITY.peoplePerSlot} sub="en observation uniquement"/>
      <Gauge i={7} icon={<Wine size={14}/>} label="Pot Green-Got" value={drinks} max={CAPACITY.drinks} sub="personnes"/>
    </div>

    <div className="grid gap-3 lg:grid-cols-3 mt-3">
      <div className="dash-card dash-in lg:col-span-2" style={delay(8)}>
        <div className="dash-label">Remplissage des créneaux</div>
        <div className="mt-3 flex flex-col gap-3">{slotStats.map((s, i) => <div key={s.slot} className="dash-slot">
          <div className="dash-slot-time">{s.slot}</div>
          <div className="flex-1 flex flex-col gap-1">
            <div className="dash-slot-line"><span>Bichonnage {s.shoe}/{s.shoeCap}</span><Bar value={s.shoe} max={s.shoeCap} i={i}/></div>
            <div className="dash-slot-line"><span>Personnes {s.people}/{CAPACITY.peoplePerSlot}</span><Bar value={s.people} max={CAPACITY.peoplePerSlot} i={i}/></div>
          </div>
          {s.fullAt ? <span className="dash-badge is-full"><Lock size={12}/>Complet</span> : s.shoeFullAt ? <span className="dash-badge"><Lock size={12}/>Bichonnage plein</span> : null}
        </div>)}</div>
      </div>
      <div className="flex flex-col gap-3">
        <div className="dash-card dash-in" style={delay(9)}>
          <div className="dash-label"><Trophy size={14}/>Les plus demandés</div>
          {ranking.length ? <ol className="mt-3 flex flex-col gap-2">{ranking.map((s, i) => <li key={s.slot} className="dash-rank"><span className="dash-rank-n">{i + 1}</span><span className="font-semibold">{s.slot}</span><span className="dash-sub ml-auto">{s.shoe}/{s.shoeCap} paires · {s.people} pers.</span></li>)}</ol> : <p className="dash-sub mt-3">Pas encore d’inscription.</p>}
        </div>
        <div className="dash-card dash-in" style={delay(10)}>
          <div className="dash-label"><Lock size={14}/>Créneaux bloqués, dans l’ordre</div>
          {blocked.length ? <ol className="mt-3 flex flex-col gap-2">{blocked.map((s) => <li key={s.slot} className="flex justify-between gap-2"><span className="font-semibold">{s.slot}</span><span className="dash-sub">{s.shoeFullAt && `plein le ${fmt(s.shoeFullAt)}`}</span></li>)}</ol> : <p className="dash-sub mt-3">Aucun créneau plein pour l’instant.</p>}
        </div>
      </div>
    </div>

    <div className="dash-card dash-in mt-3" style={delay(11)}>
      <div className="dash-label"><Users size={14}/>Inscriptions par jour</div>
      {perDay.length ? <div className="dash-chart mt-4">{perDay.map((x, i) => <div key={x.d} className="dash-col" title={`${x.r} inscriptions`}>
        <div className="dash-col-bars"><div className="dash-col-r" style={{ height: `${(x.r / maxDay) * 100}%`, ...delay(i) }}/></div>
        <span className="dash-col-label">{new Date(x.d).toLocaleDateString("fr-FR", { day: "numeric", month: "short" })}</span>
      </div>)}</div> : <p className="dash-sub mt-3">Pas encore d’inscription.</p>}
      <div className="flex gap-4 mt-3 dash-sub"><span className="flex items-center gap-1"><i className="dash-dot-r"/>Inscriptions</span></div>
    </div>
  </section>;
}
