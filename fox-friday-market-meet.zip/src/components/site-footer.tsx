export function SiteFooter() {
  return (
    <footer className="legal-footer">
      <div className="page-shell">
        <nav className="legal-footer-links" aria-label="Informations légales">
          <a href="https://green-got.com" target="_blank" rel="noreferrer">Green-Got</a>
          <a href="https://green-got.com/mentions-legales" target="_blank" rel="noreferrer">Mentions légales</a>
          <a href="https://green-got.com/politique-de-confidentialite" target="_blank" rel="noreferrer">Politique de confidentialité</a>
        </nav>
        <div className="legal-footer-copy">
          <p>Green-Got est le nom commercial de Domino SAS enregistré au RCS de Nanterre sous le numéro 883 981 763 dont le siège est situé au 20 bis rue Louis-Philippe, 92200 Neuilly-sur-Seine.</p>
          <p>Domino est un établissement de paiement régulé, agréé et supervisé par l'Autorité de Contrôle Prudentiel et de Résolution (ACPR), enregistré sous le numéro CIB 17928 et enregistré auprès de l’ORIAS en tant que Courtier en Assurance et réassurance &amp; Conseiller en Investissement Financier sous le numéro 21000544.</p>
          <p>Domino fournit des services sous le statut d’agent prestataire de services de paiement de PPS EU SA établissement de monnaie électronique agréé par la Banque Nationale de Belgique sous le numéro 0712.775.202.</p>
          <p>Carte émise par PPS EU SA conformément à la licence accordée par Mastercard® International et est un produit de services de paiement. Mastercard® est une marque déposée, et le design des cercles est une marque de Mastercard® International Incorporated.</p>
        </div>
        <p className="legal-footer-copyright">© 2026 Green-Got. Tous droits réservés.</p>
      </div>
    </footer>
  );
}