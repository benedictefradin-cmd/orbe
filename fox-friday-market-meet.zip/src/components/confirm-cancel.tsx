import type { ReactNode } from "react";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";

export function ConfirmCancel({ open, onOpenChange, onConfirm }: { open: boolean; onOpenChange: (o: boolean) => void; onConfirm: () => void }): ReactNode {
  return <AlertDialog open={open} onOpenChange={onOpenChange}>
    <AlertDialogContent>
      <AlertDialogHeader>
        <AlertDialogTitle>Vous confirmez l’annulation ?</AlertDialogTitle>
        <AlertDialogDescription>Votre place sera aussitôt donnée à une personne sur liste d’attente. Vous ne pourrez pas la récupérer ensuite. Merci pour elle !</AlertDialogDescription>
      </AlertDialogHeader>
      <AlertDialogFooter>
        <AlertDialogCancel>Je garde ma place</AlertDialogCancel>
        <AlertDialogAction onClick={onConfirm}>Oui, j’annule</AlertDialogAction>
      </AlertDialogFooter>
    </AlertDialogContent>
  </AlertDialog>;
}
