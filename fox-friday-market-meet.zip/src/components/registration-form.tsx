import { useEffect, useState, type FormEvent } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { getAvailability, submitRegistration } from "@/lib/registration.functions";
import { ArrowUpRight, MapPin, Clock3, Footprints, Eye, Wine } from "lucide-react";
import { siteUrl } from "@/lib/public-url";
import { Button } from "@/components/ui/button";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  EVENT,
  EVENT_CONSENT,
  NEWS_CONSENT,
  registrationSchema,
  registrationWindow,
  type RegistrationWindow,
  type Workshop,
} from "@/lib/fox-friday";

function Field({
  label,
  name,
  type = "text",
  placeholder,
  autoComplete,
}: {
  label: string;
  name: string;
  type?: string;
  placeholder: string;
  autoComplete?: string;
}) {
  return (
    <label className="field">
      {label}{" "}
      <input
        name={name}
        type={type}
        placeholder={placeholder}
        required
        maxLength={type === "tel" ? 30 : 254}
        autoComplete={autoComplete}
      />
    </label>
  );
}
function Binary({
  label,
  name,
  value,
  onChange,
  yes = "Oui",
  no = "Non",
}: {
  label: string;
  name: string;
  value: string;
  onChange: (value: string) => void;
  yes?: string;
  no?: string;
}) {
  return (
    <fieldset className="binary-field">
      <legend>{label}</legend>
      <div className="binary-options">
        {[
          ["yes", yes],
          ["no", no],
        ].map(([key, text]) => (
          <label key={key} className="radio-label">
            <input
              type="radio"
              name={name}
              value={key}
              checked={value === key}
              onChange={() => onChange(key ?? "")}
              required
            />
            {text}
          </label>
        ))}
      </div>
    </fieldset>
  );
}

const shareText = (url: string) =>
  `Je viens au Fox Friday de Green-Got le 27 novembre (bichonnage de chaussures + pot). Inscris-toi, les places sont très limitées : ${url}`;

export function RegistrationForm({ onDone, siteOrigin }: { onDone?: () => void; siteOrigin: string }) {
  const SHARE_URL = siteUrl(siteOrigin, "/inscription");
  const [workshop, setWorkshop] = useState<Workshop>("bichonnage");
  const [slot, setSlot] = useState("");
  const [member, setMember] = useState("");
  const [drinks, setDrinks] = useState("");
  const [image, setImage] = useState("");
  const [windowState, setWindowState] = useState<RegistrationWindow>("upcoming");
  useEffect(() => {
    const update = () => setWindowState(registrationWindow(new Date()));
    update();
    const timer = window.setInterval(update, 30000);
    return () => window.clearInterval(timer);
  }, []);
  const fetchAvailability = useServerFn(getAvailability);
  const submit = useServerFn(submitRegistration);
  const queryClient = useQueryClient();
  const { data: availability } = useQuery({
    queryKey: ["availability"],
    queryFn: () => fetchAvailability(),
    refetchInterval: 30000,
  });
  const [sending, setSending] = useState(false);
  const [copied, setCopied] = useState(false);
  const [linkCopied, setLinkCopied] = useState(false);
  const [fullSlot, setFullSlot] = useState("");
  const [error, setError] = useState("");
  const [done, setDone] = useState<{
    token: string;
    waitlisted: boolean;
    workshop: Workshop;
    slot: string;
    drinks: boolean;
  } | null>(null);
  const left = (time: string) => {
    const a = availability?.find((row) => row.slot === time);
    if (!a) return undefined;
    const people = a.peopleLeft;
    return workshop === "bichonnage" ? Math.min(a.shoeCareLeft, people) : people;
  };
  const onSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError("");
    const f = new FormData(event.currentTarget);
    const text = (k: string) => String(f.get(k) ?? "");
    const parsed = registrationSchema.safeParse({
      firstName: text("firstName"),
      lastName: text("lastName"),
      email: text("email"),
      phone: text("phone"),
      member: member === "yes" ? "oui" : "pas-encore",
      workshop,
      slot,
      staysForDrinks: workshop === "pot" || drinks === "yes",
      imageConsent: image === "yes",
      eventConsent: f.get("eventConsent") === "on",
      newsConsent: f.get("newsConsent") === "on",
    });
    if (!parsed.success) {
      setError(parsed.error.issues[0]?.message ?? "Vérifiez le formulaire.");
      return;
    }
    setSending(true);
    try {
      const result = await submit({ data: parsed.data });
      if (result.ok) {
        onDone?.();
        window.scrollTo({ top: 0 });
        setDone({
          token: result.token,
          waitlisted: result.waitlisted,
          workshop,
          slot,
          drinks: workshop === "pot" || drinks === "yes",
        });
      } else setError(result.message);
    } catch {
      setError("L’inscription n’a pas pu être envoyée. Réessayez.");
    } finally {
      setSending(false);
      void queryClient.invalidateQueries({ queryKey: ["availability"] });
    }
  };
  if (done)
    return (
      <Confirmation
        siteOrigin={siteOrigin}
        done={done}
        copied={copied}
        onCopy={() => {
          void navigator.clipboard.writeText(SHARE_URL);
          setCopied(true);
        }}
      />
    );
  const options = [
    {
      value: "bichonnage" as const,
      title: "Je fais bichonner mes chaussures",
      note: "Seulement 20 paires bichonnées sur toute la journée.",
      icon: Footprints,
    },
    {
      value: "voir" as const,
      title: "Je découvre les coulisses du savoir-faire artisanal",
      note: "Je n’apporte pas mes chaussures",
      icon: Eye,
    },
    {
      value: "pot" as const,
      title: "Je viens pour le pot à 17 h 30",
      note: "On se retrouve autour d’un verre.",
      icon: Wine,
    },
  ];
  return (
    <form onSubmit={onSubmit} aria-label="Inscription Fox Friday">
      <AlertDialog
        open={!!fullSlot}
        onOpenChange={(o) => {
          if (!o) setFullSlot("");
        }}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Le créneau de {fullSlot} est complet</AlertDialogTitle>
            <AlertDialogDescription>
              Vous pouvez quand même vous inscrire sur ce créneau : vous serez alors sur liste d’attente, sans garantie
              d’avoir une place. Si quelqu’un annule, la place vous sera attribuée automatiquement. Nous vous
              conseillons plutôt de choisir un autre créneau.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogAction onClick={() => setFullSlot("")}>J’ai compris</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      <fieldset className="form-section">
        <legend>Je viens pour</legend>
        <p className="section-help">
          Vous pouvez faire bichonner vos chaussures ou venir voir le bichonnage, puis rester au pot à 17 h 30.
          Choisissez votre atelier, ou le pot seulement.
        </p>
        <div className="choice-list" role="radiogroup" aria-label="Je viens pour">
          {options.map((option) => (
            <Button
              key={option.value}
              type="button"
              variant="outline"
              role="radio"
              aria-checked={workshop === option.value}
              data-selected={workshop === option.value}
              className="choice-option"
              onClick={() => {
                setWorkshop(option.value);
                setSlot("");
              }}
            >
              <span className="option-radio" />
              <span className="choice-copy">
                <strong>{option.title}</strong>
                <small>{option.note}</small>
              </span>
              <option.icon className="option-icon" />
            </Button>
          ))}
        </div>
        {workshop === "bichonnage" && (
          <div className="workshop-help">
            <ul className="list-disc pl-5 space-y-1">
              <li>Chaussures en cuir ou en toile (chaussures de ville, sneakers, etc.).</li>
              <li>Personnalisation Green-Got possible sur les chaussures en toile uniquement !</li>
              <li>Le bichonnage dure 40 minutes.</li>
              <li>Venez avec votre paire propre et sans réparation à faire.</li>
            </ul>
            <p className="cancel-callout">
              <strong>Les places sont rares.</strong> Si vous ne pouvez plus venir, annulez pour laisser la vôtre à
              quelqu’un d’autre.
            </p>
          </div>
        )}
      </fieldset>
      {workshop !== "pot" && (
        <fieldset className="form-section">
          <legend>Votre créneau</legend>
          <p className="section-help">
            {workshop === "voir"
              ? "40 minutes de démonstration. Arrivez 10 minutes avant."
              : "40 minutes pour prendre soin de vos chaussures. Arrivez 10 minutes avant."}
          </p>
          <div className="slot-grid" role="radiogroup" aria-label="Votre créneau">
            {EVENT.times.map((time) => {
              const n = left(time);
              const full = n === 0;
              return (
                <Button
                  type="button"
                  variant="outline"
                  className={`slot-button${n === 1 ? " slot-last" : ""}${full ? " slot-full" : ""}`}
                  role="radio"
                  aria-checked={slot === time}
                  key={time}
                  onClick={() => {
                    setSlot(time);
                    if (full) setFullSlot(time);
                  }}
                >
                  <span className="slot-time">{time}</span>
                  <small className="slot-availability">
                    {full ? (
                      <>
                        <span>Complet</span>
                        <span>Liste d’attente</span>
                      </>
                    ) : n === 1 ? (
                      "🔥 Dernière place"
                    ) : n !== undefined ? (
                      `Plus que ${n} places`
                    ) : (
                      "Disponibilité…"
                    )}
                  </small>
                </Button>
              );
            })}
          </div>
        </fieldset>
      )}
      <fieldset className="form-section">
        <legend>Faisons connaissance</legend>
        <p className="section-help">Les champs ci-dessous sont obligatoires.</p>
        <div className="form-grid">
          <Field label="Prénom" name="firstName" placeholder="Votre prénom" autoComplete="given-name" />
          <Field label="Nom" name="lastName" placeholder="Votre nom" autoComplete="family-name" />
          <Field label="Email" name="email" type="email" placeholder="vous@exemple.fr" autoComplete="email" />
          <Field label="Téléphone" name="phone" type="tel" placeholder="06 12 34 56 78" autoComplete="tel" />
        </div>
        <p className="section-help mt-2">Votre téléphone sert au rappel de la veille.</p>
        <Binary
          label="Êtes vous membre Green-Got ?"
          name="member"
          value={member}
          onChange={setMember}
          no="Pas encore"
        />
        <p className="cancel-callout mt-3">
          <strong>Vous voulez venir avec un proche ?</strong> Partagez-lui ce formulaire pour qu’il s’inscrive en
          choisissant « Je découvre les coulisses du savoir-faire artisanal » sur le même créneau que vous.
          <Button
            type="button"
            size="sm"
            variant="outline"
            className="mt-2 block"
            onClick={() => {
              void navigator.clipboard.writeText(SHARE_URL);
              setLinkCopied(true);
            }}
          >
            {linkCopied ? "Lien copié ✓" : "Copier le lien du formulaire"}
          </Button>
        </p>
        {workshop !== "pot" && (
          <Binary label="Vous restez au pot à partir de 17 h 30 ?" name="drinks" value={drinks} onChange={setDrinks} />
        )}
        <Binary
          label="J'accepte d'être photographié ou filmé pendant l'évènement pour les réseaux de Green-Got et de l'École de la Réparation"
          name="imageConsent"
          value={image}
          onChange={setImage}
        />
        <label className="consent-label">
          <input type="checkbox" name="eventConsent" required />
          {EVENT_CONSENT} *
        </label>
        <label className="consent-label">
          <input type="checkbox" name="newsConsent" />
          {NEWS_CONSENT}
        </label>
      </fieldset>
      {windowState !== "open" && (
        <div className="opening-note" role="status">
          <Clock3 size={18} />
          <div>
            <strong>
              {windowState === "upcoming"
                ? "Ouverture lundi 23 novembre à 9 h"
                : windowState === "closed"
                  ? "Les inscriptions sont closes"
                  : "Les inscriptions ne sont pas encore disponibles"}
            </strong>
            <p>
              {windowState === "upcoming"
                ? "Les inscriptions seront ouvertes jusqu’au mercredi 25 novembre à 12 h, heure de Paris."
                : windowState === "closed"
                  ? "Rendez-vous vendredi 27 novembre à L’Échappée."
                  : "L’inscription en ligne est momentanément indisponible. Écrivez à impact@green-got.com."}
            </p>
          </div>
        </div>
      )}
      {error && (
        <p
          key={error}
          ref={(el) => el?.scrollIntoView({ behavior: "smooth", block: "center" })}
          className="form-error"
          role="alert"
        >
          {error}
        </p>
      )}
      <Button className="submit-button" type="submit" disabled={windowState !== "open" || sending}>
        {sending
          ? "Envoi…"
          : workshop !== "pot" && slot && left(slot) === 0
            ? "Me mettre sur liste d’attente"
            : "Je m’inscris"}{" "}
        <ArrowUpRight size={18} />
      </Button>
      <p className="form-bottom">
        Un empêchement ?{" "}
        <a className="support-link" href="/annuler">
          Annulez votre inscription
        </a>{" "}
        ou écrivez à{" "}
        <a className="support-link" href="mailto:impact@green-got.com">
          impact@green-got.com
        </a>
        .
      </p>
    </form>
  );
}
const shift = (time: string | undefined, minutes: number) => {
  if (!time) return "";
  const [h = 0, m = 0] = time.split(" h ").map(Number);
  const t = h * 60 + m + minutes;
  return `${Math.floor(t / 60)} h ${String(t % 60).padStart(2, "0")}`;
};
const LABEL: Record<Workshop, string> = {
  bichonnage: "Bichonnage de vos chaussures",
  voir: "Vous assistez au bichonnage",
  pot: "Pot Green-Got",
};

const ADDRESS = "L’Échappée, 1 rue Grenier sur l’Eau, 75004 Paris";
const MAPS_URL = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent("1 rue Grenier sur l'Eau, 75004 Paris")}`;
/** "15 h 10" (heure de Paris, UTC+1 le 27/11) -> Date UTC */
const at = (time: string) => {
  const [h = 0, m = 0] = time.split(" h ").map(Number);
  return new Date(Date.UTC(2026, 10, 27, h - 1, m));
};
const stamp = (d: Date) =>
  d
    .toISOString()
    .replace(/[-:]/g, "")
    .replace(/\.\d{3}/, "");
function calendar(done: { token: string; workshop: Workshop; slot: string; drinks: boolean }, siteOrigin: string) {
  const hasSlot = done.workshop !== "pot" && !!done.slot;
  const start = hasSlot ? at(shift(done.slot, -10)) : at("17 h 30");
  const end = done.drinks ? at("19 h 30") : at(shift(done.slot, 40));
  const title = "Fox Friday · Green-Got";
  const cancelUrl = siteUrl(siteOrigin, `/annuler/${done.token}`);
  const paragraphs =
    done.workshop === "pot"
      ? [
          "On se retrouve à partir de 17 h 30 pour partager un verre et clôturer cette première édition du Fox Friday !",
          "L'occasion de rencontrer l'équipe Green-Got, d'échanger et de prolonger cette journée consacrée à l'École de la Réparation.",
        ]
      : done.workshop === "bichonnage"
        ? done.drinks
          ? [
              `À ${done.slot}, retrouvez les élèves de l'École de la Réparation pour un bichonnage gratuit de vos chaussures et quelques conseils pour les faire durer.`,
              "Apportez votre paire et arrivez 10 minutes avant.",
              "Puis, à partir de 17 h 30, on se retrouve autour d'un verre avec l'équipe Green-Got pour prolonger les échanges !",
            ]
          : [
              `Les élèves de l'École de la Réparation vous attendent à ${done.slot} pour bichonner gratuitement vos chaussures et vous apprendre à les entretenir.`,
              "Pensez à apporter votre paire et à arriver 10 minutes avant.",
            ]
        : done.drinks
          ? [
              `À ${done.slot}, découvrez les élèves de l'École de la Réparation à l'œuvre : démonstrations de bichonnage, conseils d'entretien et échanges autour de leur parcours.`,
              "Arrivez 10 minutes avant le début.",
              "Et à partir de 17 h 30, prolongez ce moment autour d'un verre avec l'équipe Green-Got !",
            ]
          : [
              `À ${done.slot}, venez découvrir le savoir-faire des élèves de l'École de la Réparation.`,
              "Vous pourrez les regarder bichonner des chaussures, découvrir leurs techniques et échanger avec eux sur leur parcours.",
              "Rendez-vous 10 minutes avant le début.",
            ];
  paragraphs.push("📍 Lieu : L'Échappée, 1 rue Grenier sur l'Eau, Paris 4e.");
  const cancellation = "Vous avez un empêchement ? Cliquez ici pour annuler votre réservation.";
  const details = [...paragraphs, cancellation].join("\n\n");
  const escapeHtml = (text: string) => text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  const html = [
    ...paragraphs.map(escapeHtml),
    `Vous avez un empêchement ? Cliquez <a href="${cancelUrl}">ici</a> pour annuler votre réservation.`,
  ].join("<br><br>");
  const google = `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${encodeURIComponent(title)}&dates=${stamp(start)}/${stamp(end)}&details=${encodeURIComponent(html)}&location=${encodeURIComponent(ADDRESS)}`;
  const outlook = `https://outlook.live.com/calendar/0/deeplink/compose?path=/calendar/action/compose&rru=addevent&subject=${encodeURIComponent(title)}&startdt=${start.toISOString()}&enddt=${end.toISOString()}&body=${encodeURIComponent(html)}&location=${encodeURIComponent(ADDRESS)}`;
  const esc = (t: string) =>
    t
      .replace(/\\/g, "\\\\")
      .replace(/\r?\n/g, "\\n")
      .replace(/[,;]/g, (c) => `\\${c}`);
  const ics = [
    "BEGIN:VCALENDAR",
    "VERSION:2.0",
    "PRODID:-//Green-Got//Fox Friday//FR",
    "BEGIN:VEVENT",
    `UID:fox-friday-${stamp(start)}@green-got.com`,
    `DTSTAMP:${stamp(new Date())}`,
    `DTSTART:${stamp(start)}`,
    `DTEND:${stamp(end)}`,
    `SUMMARY:${esc(title)}`,
    `DESCRIPTION:${esc(details)}`,
    `X-ALT-DESC;FMTTYPE=text/html:${esc(html)}`,
    `URL:${cancelUrl}`,
    `LOCATION:${esc(ADDRESS)}`,
    "END:VEVENT",
    "END:VCALENDAR",
  ].join("\r\n");
  return { google, outlook, ics: `data:text/calendar;charset=utf-8,${encodeURIComponent(ics)}` };
}

function Confirmation({
  done,
  copied,
  onCopy,
  siteOrigin,
}: {
  siteOrigin: string;
  done: { token: string; waitlisted: boolean; workshop: Workshop; slot: string; drinks: boolean };
  copied: boolean;
  onCopy: () => void;
}) {
  const SHARE_URL = siteUrl(siteOrigin, "/inscription");
  const SHARE_TEXT = shareText(SHARE_URL);
  const steps: { time: string; title: string; note?: string }[] = [];
  if (done.workshop && done.workshop !== "pot" && done.slot) {
    steps.push({ time: shift(done.slot, -10), title: "Arrivée à L’Échappée" });
    steps.push({
      time: `${done.slot} – ${shift(done.slot, 40)}`,
      title: LABEL[done.workshop],
      ...(done.workshop === "bichonnage" ? { note: "Paire propre, cuir ou toile" } : {}),
    });
  }
  if (done.drinks)
    steps.push({
      time: "17 h 30",
      title: "Pot Green-Got",
      ...(done.workshop === "pot" ? {} : { note: "On trinque ensemble après les ateliers" }),
    });
  return (
    <div className="confirm" role="status">
      <h2 className="confirm-title">
        {done.waitlisted ? "Vous êtes sur liste d’attente" : "Votre place a bien été réservée"}
      </h2>
      <p className="confirm-kicker">Vendredi 27 novembre</p>
      {done.waitlisted && (
        <p className="section-help">
          Vous êtes sur liste d’attente pour le créneau de {done.slot}. Si une place se libère, nous vous écrivons.
          Merci de ne pas venir sans cette confirmation.
        </p>
      )}
      {!done.waitlisted && (
        <ol className="timeline">
          {steps.map((s) => (
            <li key={s.title}>
              <span className="timeline-time">{s.time}</span>
              <span className="timeline-dot" />
              <div>
                <strong>{s.title}</strong>
                {s.note && <small>{s.note}</small>}
              </div>
            </li>
          ))}
        </ol>
      )}
      <p className="confirm-address">
        <MapPin size={16} className="inline -mt-1 mr-1" />
        <a className="support-link" href={MAPS_URL} target="_blank" rel="noreferrer">
          {ADDRESS}
        </a>
      </p>
      {!done.waitlisted &&
        (() => {
          const c = calendar(done, siteOrigin);
          return (
            <div className="confirm-block">
              <strong>Ajouter l’évènement à votre calendrier</strong>
              <div className="share-actions mt-3">
                <Button asChild variant="outline">
                  <a href={c.google} target="_blank" rel="noreferrer">
                    Google
                  </a>
                </Button>
                <Button asChild variant="outline">
                  <a href={c.outlook} target="_blank" rel="noreferrer">
                    Outlook
                  </a>
                </Button>
                <Button asChild variant="outline">
                  <a href={c.ics} download="fox-friday.ics">
                    Apple
                  </a>
                </Button>
                <Button asChild variant="outline">
                  <a href={c.ics} download="fox-friday.ics">
                    Autre (.ics)
                  </a>
                </Button>
              </div>
            </div>
          );
        })()}
      <div className="confirm-share">
        <strong>Venez avec vos proches</strong>
        <p>
          Partagez le formulaire pour qu’ils s’inscrivent
          {done.workshop !== "pot" && !done.waitlisted ? ` sur le créneau de ${done.slot}` : ""}. Les places partent
          vite.
        </p>
        <div className="share-actions">
          <Button type="button" variant="outline" onClick={onCopy}>
            {copied ? "Lien copié ✓" : "Copier le lien"}
          </Button>
          <Button asChild variant="outline">
            <a href={`https://wa.me/?text=${encodeURIComponent(SHARE_TEXT)}`} target="_blank" rel="noreferrer">
              WhatsApp
            </a>
          </Button>
          <Button asChild variant="outline">
            <a href={`sms:?&body=${encodeURIComponent(SHARE_TEXT)}`}>SMS</a>
          </Button>
          {typeof navigator !== "undefined" && "share" in navigator && (
            <Button
              type="button"
              variant="outline"
              onClick={() => {
                void navigator.share({ title: "Fox Friday", text: SHARE_TEXT, url: SHARE_URL }).catch(() => {});
              }}
            >
              Partager…
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}
