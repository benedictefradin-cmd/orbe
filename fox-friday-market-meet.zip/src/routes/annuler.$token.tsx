import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { Button } from "@/components/ui/button";
import { ConfirmCancel } from "@/components/confirm-cancel";
import { ROBOTS_POLICY } from "@/lib/robots-policy";
import { cancelRegistration } from "@/lib/registration.functions";

export const Route = createFileRoute("/annuler/$token")({
  head: () => ({
    meta: [
      { title: "Annuler mon inscription · Fox Friday" },
      { name: "description", content: "Libérez votre place au Fox Friday Green-Got pour quelqu’un d’autre." },
      { property: "og:title", content: "Annuler mon inscription · Fox Friday" },
      { property: "og:description", content: "Libérez votre place au Fox Friday Green-Got." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: ROBOTS_POLICY },
    ],
  }),
  component: CancelPage,
});

function CancelPage() {
  const { token } = Route.useParams();
  const cancel = useServerFn(cancelRegistration);
  const [state, setState] = useState<"idle" | "sending" | "done" | "missing" | "error">("idle");
  const [ask, setAsk] = useState(false);
  const onCancel = async () => {
    setState("sending");
    try { setState((await cancel({ data: { token } })).ok ? "done" : "missing"); } catch { setState("error"); }
  };
  return <main className="page-shell py-16 max-w-xl">
    <h1 className="registration-title">{state === "done" ? "C’est annulé." : "Vous ne venez plus ?"}</h1>
    {state === "done" ? <p className="mt-4">Merci d’avoir libéré votre place pour quelqu’un d’autre.</p>
    : state === "missing" ? <p className="mt-4">Cette inscription n’existe pas ou a déjà été annulée.</p>
    : <>
      <p className="mt-4">Annuler libère votre place. Cette action est définitive.</p>
      {state === "error" && <p className="form-error" role="alert">L’annulation n’a pas fonctionné. Réessayez ou écrivez à impact@green-got.com.</p>}
      <ConfirmCancel open={ask} onOpenChange={setAsk} onConfirm={() => void onCancel()}/>
      <Button className="mt-6" onClick={() => setAsk(true)} disabled={state === "sending"}>{state === "sending" ? "Annulation…" : "J’annule mon inscription"}</Button>
    </>}
    <p className="mt-8"><Link to="/" className="support-link">Retour à l’accueil</Link></p>
  </main>;
}
