import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Download, Info } from "lucide-react";
import { Button } from "@/components/ui/button";
import { AdminDashboard } from "@/components/admin-dashboard";
import { serializeCsv } from "@/lib/csv";
import { ROBOTS_POLICY } from "@/lib/robots-policy";
import { adminCancel, adminLogin, adminLogout, getAdminData, markNotified, setCheckIn, setFollowUp } from "@/lib/admin.functions";

export const Route = createFileRoute("/admin")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Administration · Fox Friday" },
      { name: "description", content: "Inscrits, accueil et exports du Fox Friday." },
      { property: "og:title", content: "Administration · Fox Friday" },
      { property: "og:description", content: "Espace réservé à l’organisatrice." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: ROBOTS_POLICY },
    ],
  }),
  component: AdminPage,
});

const WORKSHOP: Record<string, string> = { bichonnage: "Bichonnage", voir: "Observation", pot: "Pot seul" };
const STATUS = (r: { status: string; promoted_at: string | null }) => r.status === "cancelled" ? "Annulé" : r.status === "waitlist" ? "Liste d’attente" : r.promoted_at ? "Confirmé (repêché)" : "Confirmé";
const dt = (v: string | null) => v ? new Date(v).toLocaleString("fr-FR", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" }) : "";
const HELP: Record<string, string> = { all: "Toutes les inscriptions non annulées : confirmés + liste d’attente.", confirmed: "Personnes qui ont une place (dont celles repêchées de la liste d’attente).", waitlist: "Créneau complet : la première en attente récupère automatiquement une place libérée.", cancelled: "Inscriptions annulées par la personne ou par vous. Les coordonnées sont conservées." };
const yesNo = (v: boolean | null) => (v === null ? "" : v ? "oui" : "non");

function AdminPage() {
  const fetchData = useServerFn(getAdminData);
  const checkIn = useServerFn(setCheckIn);
  const cancel = useServerFn(adminCancel);
  const notified = useServerFn(markNotified);
  const follow = useServerFn(setFollowUp);
  const logout = useServerFn(adminLogout);
  const qc = useQueryClient();
  const { data, isLoading } = useQuery({ queryKey: ["admin"], queryFn: () => fetchData() });
  const [q, setQ] = useState("");
  const [tab, setTab] = useState<"all" | "confirmed" | "waitlist" | "cancelled">("all");
  const rows = useMemo(() => (data?.rows ?? []).filter((r) => tab === "all" ? r.status !== "cancelled" : r.status === tab).filter((r) => `${r.first_name} ${r.last_name} ${r.email} ${r.guest_first_name ?? ""} ${r.guest_last_name ?? ""}`.toLowerCase().includes(q.toLowerCase())), [data, q, tab]);
  if (isLoading) return <main className="page-shell py-16">Chargement…</main>;
  if (data?.status !== "ok") return <LoginForm onDone={() => qc.invalidateQueries({ queryKey: ["admin"] })}/>;
  const confirmed = data.rows.filter((r) => r.status === "confirmed");
  const people = confirmed.reduce((n, r) => n + (r.guest_email ? 2 : 1), 0);
  const arrived = confirmed.filter((r) => r.checked_in_at).reduce((n, r) => n + (r.guest_email ? 2 : 1), 0);
  const refresh = () => qc.invalidateQueries({ queryKey: ["admin"] });
  const exportCsv = () => {
    const head = ["Statut", "Parcours", "Créneau", "Prénom", "Nom", "Email", "Téléphone", "Membre", "Proche prénom", "Proche nom", "Proche email", "Proche membre", "Pot", "Accord image", "newsConsent (invitations)", "Inscrit le", "Arrivé", "Annulé le", "Annulé par", "Email envoyé le", "Commentaire", "Lien d’annulation"];
    const lines = data.rows.map((r) => [STATUS(r), WORKSHOP[r.workshop] ?? r.workshop, r.slot ?? "", r.first_name, r.last_name, r.email, r.phone, yesNo(r.member), r.guest_first_name ?? "", r.guest_last_name ?? "", r.guest_email ?? "", yesNo(r.guest_member), yesNo(r.stays_for_drinks), yesNo(r.image_consent), yesNo(r.news_consent), new Date(r.created_at).toLocaleString("fr-FR"), r.checked_in_at ? "oui" : "", r.cancelled_at ? new Date(r.cancelled_at).toLocaleString("fr-FR") : "", r.cancelled_by === "organisatrice" ? "Organisatrice" : r.cancelled_by ? "La personne" : "", r.email_sent_at ? new Date(r.email_sent_at).toLocaleString("fr-FR") : "", r.admin_comment ?? "", `${window.location.origin}/annuler/${r.cancel_token}`]);
    const csv = serializeCsv([head, ...lines]);
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob(["\ufeff" + csv], { type: "text/csv;charset=utf-8" }));
    a.download = "fox-friday-inscrits.csv"; a.click();
  };
  return <main className="page-shell py-10">
    <div className="flex justify-between items-start gap-4"><h1 className="registration-title">Inscrits</h1><Button variant="ghost" size="sm" onClick={async () => { await logout(); void refresh(); }}>Se déconnecter</Button></div>
    <AdminDashboard rows={data.rows}/>
    <p className="mt-2">{confirmed.length} inscriptions · {people} personnes · {confirmed.filter((r) => r.workshop === "bichonnage").length}/20 bichonnages · {data.rows.filter((r) => r.status === "waitlist").length} en attente · {data.rows.filter((r) => r.status === "cancelled").length} annulées · {arrived} arrivés</p>
    <div className="flex flex-wrap gap-3 my-6">
      <input className="field-input border rounded px-3 py-2 bg-transparent flex-1 min-w-[200px]" placeholder="Rechercher un nom ou un email" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Rechercher"/>
      <Button variant="outline" onClick={exportCsv}><Download size={16}/> Exporter (CSV)</Button>
    </div>
    <div className="flex flex-wrap gap-2 mb-4" role="tablist">{([["all", "Actifs"], ["confirmed", "Confirmés"], ["waitlist", "Liste d’attente"], ["cancelled", `Annulés (${data.rows.filter((r) => r.status === "cancelled").length})`]] as const).map(([k, label]) => <span key={k} className="inline-flex items-center gap-1"><Button size="sm" role="tab" aria-selected={tab === k} variant={tab === k ? "default" : "outline"} onClick={() => setTab(k)}>{label}</Button><span title={HELP[k]} aria-label={HELP[k]} className="cursor-help opacity-60 hover:opacity-100"><Info size={14}/></span></span>)}</div>
    <div className="overflow-x-auto"><table className="w-full text-sm">
      <thead><tr className="text-left border-b border-border">{["Arrivé", "Créneau", "Parcours", "Nom", "Proche", "Contact", "Invitations", "Statut", "Inscrit·e le", "Email envoyé", "Commentaire", ""].map((h) => <th key={h} className="py-2 pr-3">{h}</th>)}</tr></thead>
      <tbody>{rows.map((r) => <tr key={r.id} className="border-b border-border align-top">
        <td className="py-2 pr-3"><input type="checkbox" aria-label={`Arrivée de ${r.first_name} ${r.last_name}`} checked={!!r.checked_in_at} disabled={r.status !== "confirmed"} onChange={async (e) => { await checkIn({ data: { id: r.id, arrived: e.target.checked } }); void refresh(); }}/></td>
        <td className="py-2 pr-3 whitespace-nowrap">{r.slot ?? "17 h 30"}</td>
        <td className="py-2 pr-3">{WORKSHOP[r.workshop]}</td>
        <td className="py-2 pr-3">{r.first_name} {r.last_name}{r.member ? " · membre" : ""}</td>
        <td className="py-2 pr-3">{r.guest_email ? `${r.guest_first_name} ${r.guest_last_name}${r.guest_member ? " · membre" : " · non membre"}` : "—"}</td>
        <td className="py-2 pr-3">{r.email}<br/>{r.phone}</td>
        <td className="py-2 pr-3">{r.news_consent ? "Oui" : "Non"}</td>
        <td className="py-2 pr-3">{STATUS(r)}{r.cancelled_at && <span className="block text-xs opacity-70">le {new Date(r.cancelled_at).toLocaleString("fr-FR", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" })} · {r.cancelled_by === "organisatrice" ? "par vous" : "par la personne"}</span>}</td>
        <td className="py-2 pr-3 whitespace-nowrap text-xs">{dt(r.created_at)}{r.promoted_at && <span className="block opacity-70">repêché·e {dt(r.promoted_at)}</span>}</td>
        <td className="py-2 pr-3 text-xs"><label className="inline-flex items-center gap-1"><input type="checkbox" checked={!!r.email_sent_at} onChange={async (e) => { await follow({ data: { id: r.id, emailSent: e.target.checked } }); void refresh(); }}/>{r.email_sent_at ? dt(r.email_sent_at) : "Non"}</label></td>
        <td className="py-2 pr-3"><textarea key={r.admin_comment ?? ""} defaultValue={r.admin_comment ?? ""} rows={1} maxLength={1000} placeholder="Commentaire" aria-label={`Commentaire pour ${r.first_name} ${r.last_name}`} className="border border-border rounded px-2 py-1 bg-transparent text-xs w-40" onBlur={async (e) => { if (e.target.value !== (r.admin_comment ?? "")) { await follow({ data: { id: r.id, comment: e.target.value } }); void refresh(); } }}/></td>
        <td className="py-2 whitespace-nowrap">{r.promoted_at && !r.promotion_notified_at && <Button size="sm" asChild onClick={async () => { await notified({ data: { id: r.id } }); void refresh(); }}><a href={`mailto:${r.email}?cc=impact@green-got.com&subject=${encodeURIComponent("Fox Friday : une place s’est libérée pour vous")}&body=${encodeURIComponent(`Bonjour ${r.first_name},\n\nBonne nouvelle : une place s’est libérée${r.slot ? ` à ${r.slot}` : ""} pour le Fox Friday, vendredi 27 novembre à L’Échappée, 1 rue Grenier sur l’Eau, Paris 4e. Votre inscription est confirmée.\n\nSi vous ne pouvez plus venir, annulez ici pour laisser la place à quelqu’un d’autre : ${window.location.origin}/annuler/${r.cancel_token}\n\nÀ vendredi !\nL’équipe Green-Got`)}`}>Prévenir</a></Button>}{r.promotion_notified_at && <span className="text-xs mr-2">Prévenu·e</span>}{r.status !== "cancelled" && <Button size="sm" variant="ghost" onClick={async () => { if (confirm(`Annuler l’inscription de ${r.first_name} ${r.last_name} ?`)) { await cancel({ data: { id: r.id } }); void refresh(); } }}>Annuler</Button>}</td>
      </tr>)}</tbody>
    </table>{rows.length === 0 && <p className="py-6">Aucune inscription pour l’instant.</p>}</div>
  </main>;
}

function LoginForm({ onDone }: { onDone: () => void }) {
  const login = useServerFn(adminLogin);
  const [error, setError] = useState(false);
  const [busy, setBusy] = useState(false);
  return <main className="page-shell py-16 max-w-sm">
    <h1 className="registration-title">Administration</h1>
    <form className="mt-6 flex flex-col gap-3" onSubmit={async (e) => {
      e.preventDefault(); setBusy(true); setError(false);
      const f = new FormData(e.currentTarget);
      const res = await login({ data: { user: String(f.get("user")), pass: String(f.get("pass")) } });
      setBusy(false);
      if (res.ok) onDone(); else setError(true);
    }}>
      <label className="flex flex-col gap-1">Identifiant<input name="user" autoComplete="username" required className="border rounded px-3 py-2 bg-transparent"/></label>
      <label className="flex flex-col gap-1">Mot de passe<input name="pass" type="password" autoComplete="current-password" required className="border rounded px-3 py-2 bg-transparent"/></label>
      {error && <p role="alert">Identifiant ou mot de passe incorrect.</p>}
      <Button type="submit" disabled={busy}>{busy ? "Connexion…" : "Se connecter"}</Button>
    </form>
  </main>;
}

