import { useState, type FormEvent } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { Button } from "@/components/ui/button";
import { ConfirmCancel } from "@/components/confirm-cancel";
import { cancelByContact } from "@/lib/registration.functions";

export const Route = createFileRoute("/annuler/")({
  head: () => ({
    meta: [
      { title: "Annuler mon inscription · Fox Friday" },
      { name: "description", content: "Vous ne venez plus au Fox Friday ? Libérez votre place en deux champs." },
      { property: "og:title", content: "Annuler mon inscription · Fox Friday" },
      { property: "og:description", content: "Libérez votre place au Fox Friday Green-Got." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: CancelByContact,
});

function CancelByContact() {
  const cancel = useServerFn(cancelByContact);
  const [state, setState] = useState<"idle" | "sending" | "done" | "missing" | "error">("idle");
  const [pending, setPending] = useState<{ email: string; phone: string } | null>(null);
  const onSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    setPending({ email: String(f.get("email")), phone: String(f.get("phone")) });
  };
  const confirmCancel = async () => {
    if (!pending) return;
    const data = pending; setPending(null);
    setState("sending");
    try { setState((await cancel({ data })).ok ? "done" : "missing"); } catch { setState("error"); }
  };
  return <main className="page-shell py-16 max-w-xl">
    <h1 className="registration-title">{state === "done" ? "C’est annulé." : "Vous ne venez plus ?"}</h1>
    {state === "done" ? <p className="mt-4">Merci d’avoir libéré votre place pour quelqu’un d’autre.</p> : <form onSubmit={onSubmit} className="mt-4">
      <p>Indiquez l'email et le téléphone donnés à l'inscription.</p>
      <div className="form-grid mt-4">
        <label className="field">Email <input name="email" type="email" required maxLength={254} autoComplete="email" placeholder="vous@exemple.fr"/></label>
        <label className="field">Téléphone <input name="phone" type="tel" required maxLength={30} autoComplete="tel" placeholder="06 12 34 56 78"/></label>
      </div>
      {state === "missing" && <p className="form-error" role="alert">Aucune inscription ne correspond. Vérifiez vos informations ou écrivez à impact@green-got.com.</p>}
      {state === "error" && <p className="form-error" role="alert">L’annulation n’a pas fonctionné. Réessayez.</p>}
      <Button className="mt-6" type="submit" disabled={state === "sending"}>{state === "sending" ? "Annulation…" : "J’annule mon inscription"}</Button>
      <ConfirmCancel open={!!pending} onOpenChange={(o) => { if (!o) setPending(null); }} onConfirm={() => void confirmCancel()}/>
    </form>}
    <p className="mt-8"><Link to="/" className="support-link">Retour à l’accueil</Link></p>
  </main>;
}
