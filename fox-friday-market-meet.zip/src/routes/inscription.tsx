import { getRequestOrigin } from "@/lib/origin.functions";
import { siteUrl } from "@/lib/public-url";
import shareImage from "@/assets/img/fox-friday-share.webp.asset.json";
import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";
import { RegistrationForm } from "@/components/registration-form";
import { EVENT } from "@/lib/fox-friday";
export const Route = createFileRoute("/inscription")({
  loader: () => getRequestOrigin(),
  head: ({ loaderData: origin }) => ({ meta: [
    { title: "Je viens au Fox Friday — Green-Got" },
    { name: "description", content: "Réservez votre créneau de bichonnage ou votre place au pot du Fox Friday, le 27 novembre 2026 à L’Échappée, Paris 4e." },
    { property: "og:title", content: "Je viens au Fox Friday" },
    { property: "og:description", content: "20 paires bichonnées seulement. Réservez votre créneau." },
    { property: "og:type", content: "website" },
    ...(origin ? [
      { property: "og:image", content: siteUrl(origin, shareImage.url) },
      { name: "twitter:image", content: siteUrl(origin, shareImage.url) },
    ] : []),
    { property: "og:image:width", content: "1200" },
    { property: "og:image:height", content: "630" },
    { property: "og:image:alt", content: "Fox Friday · Green-Got et l’École de la Réparation" },
    { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: Inscription,
});
function Inscription() {
  const siteOrigin = Route.useLoaderData();
  const [done, setDone] = useState(false);
  return <main className="registration-band">
    <div className="page-shell">
      <Link to="/" className="back-link"><ArrowLeft size={13}/>Fox Friday</Link>
      {!done && <p className="fomo">Places très limitées pour les ateliers</p>}
      <RegistrationForm siteOrigin={siteOrigin} onDone={() => setDone(true)}/>
    </div>
  </main>;
}
