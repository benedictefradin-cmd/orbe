<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# Cap

Les visiteurs participent à un atelier Fox Friday en boutique.

## Indicateur

Personnes qui s'inscrivent à un créneau d'atelier chaque semaine
